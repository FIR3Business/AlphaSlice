from __future__ import annotations

import io
import base64
import json
import math
import os
import re
import subprocess
import sys
import shutil
import urllib.error
import urllib.request
import urllib.parse
import time
import platform
import zipfile
import tempfile
import traceback
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np
import trimesh
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import HTMLResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"
TEMPLATE_DIR = BASE_DIR / "templates"
# Keep runtime-generated Orca project files in a user-writable temp location.
# This avoids HTTP 500 errors when AlphaSlice is unzipped beneath a protected or
# synced Windows folder.
EXPORT_DIR = Path(tempfile.gettempdir()) / "AlphaSlice" / "exports"
EXPORT_DIR.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="AlphaSlice", version="1.34.0")
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
app.mount("/samples", StaticFiles(directory=BASE_DIR.parent / "samples"), name="samples")

SESSIONS: Dict[str, Dict[str, Any]] = {}
PLUGIN_STATE: Dict[str, Any] = {"last_heartbeat": 0.0, "plugin_version": None, "recommendation": None}


@app.middleware("http")
async def disable_browser_cache(request, call_next):
    # Local hackathon app changes quickly; stale JS/CSS caused old UI behavior to
    # survive across versions. Force the browser to load the current build.
    response = await call_next(request)
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"
    return response


class ExportRequest(BaseModel):
    session_id: str
    option: str = "balanced"
    printer: str = "creality_k2_plus"


class OrientRequest(BaseModel):
    session_id: str
    mode: str
    face_index: Optional[int] = None


class SupportRequest(BaseModel):
    session_id: str
    overhang_angle_deg: float = 48.0


class SupportExportRequest(BaseModel):
    session_id: str


class VisionOpsAnalyzeRequest(BaseModel):
    image_data_url: str
    api_key: str = ""
    context: str = ""


class GroqAccessCheckRequest(BaseModel):
    api_key: str = ""


class VisionOpsDiscordRequest(BaseModel):
    webhook_url: str
    incident: Dict[str, Any]
    image_data_url: Optional[str] = None
    test: bool = False
    channel_type: str = "update"


class FluiddConnectionRequest(BaseModel):
    base_url: str
    api_key: str = ""
    pause_command: str = "PAUSE"


class FluiddActionRequest(BaseModel):
    base_url: str
    api_key: str = ""
    pause_command: str = "PAUSE"
    action: str = "pause"


def _new_id() -> str:
    return os.urandom(8).hex()


def _load_mesh(filename: str, raw: bytes) -> trimesh.Trimesh:
    ext = Path(filename).suffix.lower()
    if ext not in {".stl", ".3mf", ".obj", ".ply"}:
        raise HTTPException(status_code=400, detail="AlphaSlice v0.2 supports STL, 3MF, OBJ and PLY. STEP is the next importer.")
    try:
        loaded = trimesh.load(io.BytesIO(raw), file_type=ext.lstrip("."), force="scene")
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Could not read model: {exc}")
    if isinstance(loaded, trimesh.Scene):
        if not loaded.geometry:
            raise HTTPException(status_code=400, detail="No printable mesh geometry found.")
        mesh = trimesh.util.concatenate(tuple(g for g in loaded.geometry.values()))
    else:
        mesh = loaded
    if not isinstance(mesh, trimesh.Trimesh) or len(mesh.vertices) < 4 or len(mesh.faces) < 4:
        raise HTTPException(status_code=400, detail="Model does not contain a usable triangular mesh.")
    mesh = mesh.copy()
    try:
        mesh.remove_unreferenced_vertices()
        mesh.merge_vertices()
    except Exception:
        pass
    return mesh




def _mesh_edge_health(mesh: trimesh.Trimesh) -> Dict[str, int]:
    """Return boundary/non-manifold edge counts after topological vertex welding."""
    probe = mesh.copy()
    try:
        probe.merge_vertices()
        probe.remove_unreferenced_vertices()
    except Exception:
        pass
    if len(probe.faces) == 0:
        return {"boundary": 0, "nonmanifold": 0, "bad_total": 0}
    edges = np.sort(np.asarray(probe.edges, dtype=np.int64), axis=1)
    if len(edges) == 0:
        return {"boundary": 0, "nonmanifold": 0, "bad_total": 0}
    _, counts = np.unique(edges, axis=0, return_counts=True)
    boundary = int(np.count_nonzero(counts == 1))
    nonmanifold = int(np.count_nonzero(counts > 2))
    return {"boundary": boundary, "nonmanifold": nonmanifold, "bad_total": boundary + nonmanifold}


def _windows_native_repair(mesh: trimesh.Trimesh) -> tuple[Optional[trimesh.Trimesh], Dict[str, Any]]:
    """Repair a mesh with Windows.Graphics.Printing3D.RepairAsync without resampling.

    AlphaSlice writes the model to a temporary generic 3MF, invokes a PowerShell
    helper that calls Windows' native 3D repair API, then reloads the repaired
    geometry. This mirrors the Windows-only "Fix Model" capability exposed by
    slicers while keeping AlphaSlice's final slicer metadata separate.
    """
    info: Dict[str, Any] = {
        "attempted": False,
        "available": os.name == "nt",
        "succeeded": False,
        "engine": "Windows.Graphics.Printing3D.Printing3DModel.RepairAsync",
    }
    if os.name != "nt":
        info["reason"] = "Windows native repair is only available on Windows."
        return None, info
    script = BASE_DIR.parent / "scripts" / "windows_fix_model.ps1"
    if not script.exists():
        info["reason"] = f"Repair helper is missing: {script}"
        return None, info
    info["attempted"] = True
    try:
        with tempfile.TemporaryDirectory(prefix="ecoslice_fixmodel_") as td:
            td = Path(td)
            src = td / "input.3mf"
            dst = td / "repaired.3mf"
            src.write_bytes(trimesh.exchange.threemf.export_3MF(mesh))
            cmd = [
                "powershell.exe", "-NoLogo", "-NoProfile", "-ExecutionPolicy", "Bypass",
                "-File", str(script), "-Input3MF", str(src), "-Output3MF", str(dst),
            ]
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=90)
            info["return_code"] = int(proc.returncode)
            if proc.stdout.strip(): info["stdout"] = proc.stdout.strip()[-1500:]
            if proc.stderr.strip(): info["stderr"] = proc.stderr.strip()[-2000:]
            if proc.returncode != 0 or not dst.exists() or dst.stat().st_size < 100:
                info["reason"] = "Windows Fix Model repair failed."
                return None, info
            raw = dst.read_bytes()
            loaded = trimesh.load(io.BytesIO(raw), file_type="3mf", force="scene")
            if isinstance(loaded, trimesh.Scene):
                if not loaded.geometry:
                    info["reason"] = "Windows repair returned a 3MF with no mesh geometry."
                    return None, info
                repaired = trimesh.util.concatenate(tuple(g for g in loaded.geometry.values()))
            else:
                repaired = loaded
            if not isinstance(repaired, trimesh.Trimesh) or len(repaired.faces) == 0:
                info["reason"] = "Windows repair returned unusable mesh geometry."
                return None, info
            repaired = repaired.copy()
            repaired.remove_unreferenced_vertices()
            info["succeeded"] = True
            info["faces"] = int(len(repaired.faces))
            info["vertices"] = int(len(repaired.vertices))
            return repaired, info
    except subprocess.TimeoutExpired:
        info["reason"] = "Windows Fix Model repair timed out after 90 seconds."
    except Exception as exc:
        info["reason"] = f"Windows Fix Model repair error: {type(exc).__name__}: {exc}"
    return None, info



def _orcaslicer_cli_repair(mesh: trimesh.Trimesh) -> tuple[Optional[trimesh.Trimesh], Dict[str, Any]]:
    """Best-effort full-resolution fallback using Orca/Slic3r's legacy --repair action."""
    info: Dict[str, Any] = {"attempted": False, "succeeded": False, "engine": "OrcaSlicer --repair"}
    try:
        exe = _find_orcaslicer()
    except Exception:
        exe = None
    if not exe:
        info["reason"] = "OrcaSlicer executable was not detected."
        return None, info
    info["attempted"] = True
    info["executable"] = exe
    try:
        with tempfile.TemporaryDirectory(prefix="ecoslice_orcarepair_") as td:
            td = Path(td)
            src = td / "model.stl"
            src.write_bytes(trimesh.exchange.stl.export_stl(mesh))
            proc = subprocess.run([exe, "--repair", str(src)], cwd=str(td), capture_output=True, text=True, timeout=45)
            info["return_code"] = int(proc.returncode)
            if proc.stdout.strip(): info["stdout"] = proc.stdout.strip()[-1000:]
            if proc.stderr.strip(): info["stderr"] = proc.stderr.strip()[-1500:]
            candidates = [td / "model_fixed.obj", td / "model_fixed.stl"]
            candidates += list(td.glob("*_fixed.obj")) + list(td.glob("*_fixed.stl"))
            fixed = next((q for q in candidates if q.exists() and q.stat().st_size > 100), None)
            if proc.returncode != 0 or fixed is None:
                info["reason"] = "OrcaSlicer did not produce a repaired mesh from --repair."
                return None, info
            loaded = trimesh.load(str(fixed), force="scene")
            if isinstance(loaded, trimesh.Scene):
                if not loaded.geometry: return None, {**info, "reason": "Orca repair output contained no geometry."}
                repaired = trimesh.util.concatenate(tuple(g for g in loaded.geometry.values()))
            else:
                repaired = loaded
            if not isinstance(repaired, trimesh.Trimesh) or len(repaired.faces) == 0:
                return None, {**info, "reason": "Orca repair output was not a usable mesh."}
            repaired = repaired.copy(); repaired.remove_unreferenced_vertices()
            info["succeeded"] = True
            return repaired, info
    except subprocess.TimeoutExpired:
        info["reason"] = "OrcaSlicer --repair timed out."
    except Exception as exc:
        info["reason"] = f"OrcaSlicer repair error: {type(exc).__name__}: {exc}"
    return None, info

def _repair_mesh_for_export(mesh: trimesh.Trimesh, nozzle_mm: float = 0.4) -> tuple[trimesh.Trimesh, Dict[str, Any]]:
    """Preserve full model resolution and use native Windows repair when available.

    No voxel remesh, marching cubes, decimation, or surface resampling is used.
    On Windows, AlphaSlice first calls the same Windows.Graphics.Printing3D repair
    stack used by slicers' Fix Model workflow. If that API is unavailable, a
    conservative topology-only cleanup is used as a fallback.
    """
    original = mesh.copy()
    before = _mesh_edge_health(original)
    original_faces = int(len(original.faces))
    original_vertices = int(len(original.vertices))

    win_mesh, win_info = _windows_native_repair(original)
    if win_mesh is not None:
        after = _mesh_edge_health(win_mesh)
        return win_mesh, {
            "method": "windows_native_fix_model",
            "before": before,
            "after": after,
            "watertight": bool(win_mesh.is_watertight and after["bad_total"] == 0),
            "surface_resampled": False,
            "voxel_remesh_used": False,
            "original_faces": original_faces,
            "export_faces": int(len(win_mesh.faces)),
            "original_vertices": original_vertices,
            "export_vertices": int(len(win_mesh.vertices)),
            "windows_fix_model": win_info,
            "slicer_repair_recommended": bool(after["bad_total"] != 0),
        }

    orca_mesh, orca_info = _orcaslicer_cli_repair(original)
    if orca_mesh is not None:
        after = _mesh_edge_health(orca_mesh)
        return orca_mesh, {
            "method": "orcaslicer_cli_repair",
            "before": before,
            "after": after,
            "watertight": bool(orca_mesh.is_watertight and after["bad_total"] == 0),
            "surface_resampled": False,
            "voxel_remesh_used": False,
            "original_faces": original_faces,
            "export_faces": int(len(orca_mesh.faces)),
            "original_vertices": original_vertices,
            "export_vertices": int(len(orca_mesh.vertices)),
            "windows_fix_model": win_info,
            "orca_cli_repair": orca_info,
            "slicer_repair_recommended": bool(after["bad_total"] != 0),
        }

    repaired = original.copy()
    try:
        repaired.remove_unreferenced_vertices()
        if hasattr(repaired, "nondegenerate_faces"):
            repaired.update_faces(repaired.nondegenerate_faces())
        if hasattr(repaired, "unique_faces"):
            repaired.update_faces(repaired.unique_faces())
        repaired.remove_unreferenced_vertices()
        try: repaired.merge_vertices()
        except Exception: pass
        try: trimesh.repair.fix_winding(repaired)
        except Exception: pass
        try: trimesh.repair.fix_normals(repaired, multibody=True)
        except Exception: pass
        try: trimesh.repair.fill_holes(repaired)
        except Exception: pass
        repaired.remove_unreferenced_vertices()
    except Exception:
        repaired = original.copy()

    after = _mesh_edge_health(repaired)
    return repaired, {
        "method": "full_resolution_topology_cleanup_fallback",
        "before": before,
        "after": after,
        "watertight": bool(repaired.is_watertight and after["bad_total"] == 0),
        "surface_resampled": False,
        "voxel_remesh_used": False,
        "original_faces": original_faces,
        "export_faces": int(len(repaired.faces)),
        "original_vertices": original_vertices,
        "export_vertices": int(len(repaired.vertices)),
        "windows_fix_model": win_info,
        "orca_cli_repair": orca_info,
        "slicer_repair_recommended": bool(after["bad_total"] != 0),
    }

def _translate_to_bed(mesh: trimesh.Trimesh) -> None:
    min_z = float(mesh.bounds[0][2])
    mesh.apply_translation([0.0, 0.0, -min_z])


def _rotation_from_vectors(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    a = np.array(a, dtype=float, copy=True); b = np.array(b, dtype=float, copy=True)
    a /= max(np.linalg.norm(a), 1e-12); b /= max(np.linalg.norm(b), 1e-12)
    dot = float(np.clip(np.dot(a, b), -1.0, 1.0))
    if dot > 0.999999:
        return np.eye(4)
    if dot < -0.999999:
        axis = np.cross(a, np.array([1.0, 0.0, 0.0]))
        if np.linalg.norm(axis) < 1e-8:
            axis = np.cross(a, np.array([0.0, 1.0, 0.0]))
        axis /= np.linalg.norm(axis)
        return trimesh.transformations.rotation_matrix(math.pi, axis)
    axis = np.cross(a, b)
    axis /= max(np.linalg.norm(axis), 1e-12)
    return trimesh.transformations.rotation_matrix(math.acos(dot), axis)


def _strength_recommendation(prompt: str, load_newtons: Optional[float], environment: List[str]) -> Dict[str, Any]:
    text=(prompt or "").lower()
    score=0
    reasons=[]
    if load_newtons is not None:
        if load_newtons >= 250:
            score += 4; reasons.append("high stated load")
        elif load_newtons >= 100:
            score += 3; reasons.append("moderate stated load")
        elif load_newtons >= 30:
            score += 2; reasons.append("functional stated load")
        elif load_newtons > 0:
            score += 1; reasons.append("light stated load")
    if "vibration" in environment:
        score += 2; reasons.append("vibration/fatigue exposure")

    # Impact language must create a hard strength floor. This is deliberately
    # deterministic so an LLM interpretation can never downgrade an explicitly
    # impact-loaded part to LIGHT/FUNCTIONAL settings.
    severe_impact_phrases = [
        "hard hit", "hard hits", "repeated hit", "repeated hits",
        "repeated impact", "high impact", "heavy impact", "collision",
        "slam", "slamming", "ramming", "takes hits", "take hits",
        "must take hits", "must withstand hits", "violent impact",
    ]
    if any(k in text for k in severe_impact_phrases):
        score += 5; reasons.append("explicit hard/repeated impact requirement")
    elif any(k in text for k in ["impact","shock","crash","drop","hammer","hit","hits","lever","cantilever"]):
        score += 2; reasons.append("impact or bending language")

    if any(k in text for k in ["frc","first robotics competition","ftc","robot intake","robotics intake"]):
        score += 2; reasons.append("competition-robot impact/vibration duty")
    if any(k in text for k in ["structural","load bearing","load-bearing","mount","bracket","brace","clamp","holder","intake"]):
        score += 1; reasons.append("functional mounting/structural use")
    if any(k in text for k in ["toy","decorative","display","prototype","mockup","cosmetic"]):
        score -= 2; reasons.append("non-structural use")
    if any(k in text for k in ["safety critical","safety-critical","human weight","vehicle suspension","medical"]):
        score += 4; reasons.append("safety-critical language")

    if score <= 0:
        level="LIGHT"; walls=2; infill=8; pattern="gyroid"; top=3; bottom=3; sf=1.4
    elif score <= 2:
        level="FUNCTIONAL"; walls=3; infill=15; pattern="gyroid"; top=4; bottom=4; sf=1.8
    elif score <= 5:
        level="STRUCTURAL"; walls=4; infill=25; pattern="gyroid"; top=5; bottom=5; sf=2.3
    else:
        # Impact-loaded brackets/braces benefit more from perimeter thickness than
        # simply pushing infill toward 100%. Keep a strong but printable baseline.
        level="HEAVY"; walls=6; infill=40; pattern="gyroid"; top=7; bottom=7; sf=3.2
    return {
        "level": level,
        "score": score,
        "wall_loops": walls,
        "infill_density_pct": infill,
        "infill_pattern": pattern,
        "top_shell_layers": top,
        "bottom_shell_layers": bottom,
        "target_safety_factor": sf,
        "reasons": reasons or ["no strong structural cues detected"],
        "note": "Intent-derived starting point; real FEA/load testing is required before safety-critical use."
    }


def _parse_intent_local(prompt: str) -> Dict[str, Any]:
    text = (prompt or "").strip().lower()
    result: Dict[str, Any] = {
        "summary": prompt.strip() or "No use-case description provided",
        "load_newtons": None,
        "load_direction": "-Z",
        "environment": [],
        "priority": {"strength": 0.45, "material": 0.40, "appearance": 0.15},
        "assumptions": [],
        "source": "Local deterministic parser",
    }
    kg = re.search(r"(\d+(?:\.\d+)?)\s*kg", text)
    lb = re.search(r"(\d+(?:\.\d+)?)\s*(?:lb|lbs|pounds?)", text)
    n = re.search(r"(\d+(?:\.\d+)?)\s*n(?:ewtons?)?\b", text)
    if n:
        result["load_newtons"] = round(float(n.group(1)), 2)
    elif kg:
        result["load_newtons"] = round(float(kg.group(1)) * 9.80665, 2)
        result["assumptions"].append("Converted stated mass to gravity load using 9.80665 m/s².")
    elif lb:
        result["load_newtons"] = round(float(lb.group(1)) * 4.44822, 2)
        result["assumptions"].append("Converted stated pounds-force to newtons.")

    if any(k in text for k in ["upward", "upwards", "lift"]): result["load_direction"] = "+Z"
    elif any(k in text for k in ["sideways", "lateral", "side load", "shear"]): result["load_direction"] = "+X"
    elif any(k in text for k in ["downward", "downwards", "hanging", "shelf", "mount"]): result["load_direction"] = "-Z"

    if any(k in text for k in ["outdoor", "outside", "sun", "uv"]): result["environment"].append("outdoor")
    if any(k in text for k in ["vibration", "vibrating", "motor", "drone"]):
        result["environment"].append("vibration")
        result["priority"] = {"strength": 0.60, "material": 0.30, "appearance": 0.10}
    if any(k in text for k in ["decorative", "appearance", "cosmetic", "display"]):
        result["priority"] = {"strength": 0.30, "material": 0.30, "appearance": 0.40}
    if any(k in text for k in ["lightweight", "minimum material", "eco", "reduce material"]):
        result["priority"] = {"strength": 0.35, "material": 0.55, "appearance": 0.10}
    if result["load_newtons"] is None:
        result["assumptions"].append("No explicit load magnitude detected; strength selection uses the described function and risk cues.")
    result["strength_recommendation"]=_strength_recommendation(prompt,result["load_newtons"],result["environment"])
    return result

def _extract_json_object_text(text: str) -> str:
    raw = (text or "").strip()
    if not raw:
        raise RuntimeError("Model returned empty output")
    if raw.startswith("```"):
        raw = re.sub(r"^```(?:json)?\s*", "", raw.strip(), flags=re.IGNORECASE)
        raw = re.sub(r"\s*```$", "", raw.strip())
    candidates = [raw]
    if "{" in raw and "}" in raw:
        candidates.append(raw[raw.find("{"): raw.rfind("}") + 1])
    for candidate in candidates:
        candidate = candidate.strip()
        if not candidate:
            continue
        try:
            json.loads(candidate)
            return candidate
        except Exception:
            pass
    raise RuntimeError(f"Could not parse JSON from model output: {raw[:300]}")


GROQ_HTTP_USER_AGENT = "AlphaSlice/1.26 (+https://localhost)"

def _groq_headers(api_key: str) -> Dict[str, str]:
    # Groq sits behind Cloudflare. Python urllib's default User-Agent can be
    # rejected with HTTP 403 / Cloudflare error 1010 even when the API key and
    # model permissions are valid. Always send an application User-Agent.
    return {
        "Authorization": f"Bearer {api_key.strip()}",
        "Content-Type": "application/json",
        "Accept": "application/json",
        "User-Agent": GROQ_HTTP_USER_AGENT,
    }

def _groq_generate_json(prompt: str, api_key: str, image_data_url: str | None = None, model: str = "qwen/qwen3.8-27b") -> Dict[str, Any]:
    if not api_key.strip():
        raise ValueError("Groq API key is required")
    if image_data_url:
        content: Any = [
            {"type": "text", "text": prompt},
            {"type": "image_url", "image_url": {"url": image_data_url}},
        ]
    else:
        content = prompt
    body = {
        "model": model,
        "messages": [{"role": "user", "content": content}],
        "temperature": 0.05,
        "max_completion_tokens": 700,
        # Keep the full visible response, but disable Qwen's hidden reasoning tokens.
        # Hidden reasoning was consuming OTPM and causing repeated 429s during camera monitoring.
        "reasoning_effort": "none",
        "response_format": {"type": "json_object"},
    }
    req = urllib.request.Request(
        "https://api.groq.com/openai/v1/chat/completions",
        data=json.dumps(body).encode("utf-8"),
        headers=_groq_headers(api_key),
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=35) as r:
        payload = json.loads(r.read().decode("utf-8"))
    choices = payload.get("choices") or []
    if not choices:
        raise RuntimeError("Groq returned no choices")
    message = choices[0].get("message", {}).get("content", "")
    if isinstance(message, list):
        text = "".join(str(x.get("text") or x.get("content") or "") if isinstance(x, dict) else str(x) for x in message).strip()
    else:
        text = str(message or "").strip()
    if not text:
        raise RuntimeError("Groq returned no text output")
    return json.loads(_extract_json_object_text(text))


def _parse_intent_groq(prompt: str, api_key: str) -> Optional[Dict[str, Any]]:
    if not prompt.strip() or not api_key.strip():
        return None
    schema = {
        "summary": "short restatement",
        "load_newtons": None,
        "load_direction": "-Z/+Z/+X/-X/+Y/-Y",
        "environment": ["outdoor/vibration/etc"],
        "priority": {"strength": 0.45, "material": 0.4, "appearance": 0.15},
        "assumptions": ["explicit assumptions only"],
    }
    instruction = (
        "You convert a 3D-print part use case into conservative engineering intent. "
        "Preserve explicit impact, collision, repeated-hit, vibration, robotics-competition, brace, bracket, and structural-duty cues in the summary/environment; never soften them. "
        "Do not invent exact loads. Return JSON only matching this schema: "
        + json.dumps(schema)
        + "\nUser description: " + prompt
    )
    try:
        parsed = _groq_generate_json(instruction, api_key, model="qwen/qwen3.8-27b")
        local = _parse_intent_local(prompt)
        local.update({k: parsed[k] for k in parsed if k in local})
        local["source"] = "Groq + local validation"
        local["strength_recommendation"] = _strength_recommendation(prompt, local.get("load_newtons"), local.get("environment") or [])
        return local
    except Exception:
        return None


def _support_metrics(mesh: trimesh.Trimesh) -> Dict[str, float]:
    normals = np.asarray(mesh.face_normals); areas = np.asarray(mesh.area_faces)
    if len(areas) == 0 or float(areas.sum()) <= 0:
        return {"overhang_area": 0.0, "support_ratio": 0.0, "height": 0.0, "eco_score": 0.0}
    threshold = -math.cos(math.radians(45))
    downward = normals[:, 2] < threshold
    overhang_area = float(areas[downward].sum()); total_area = float(areas.sum())
    ratio = overhang_area / max(total_area, 1e-9)
    extents = np.asarray(mesh.extents, dtype=float); height = float(extents[2]); base = max(float(max(extents)), 1e-6)
    eco_score = ratio * 0.75 + (height / base) * 0.25
    return {"overhang_area": round(overhang_area, 3), "support_ratio": round(ratio, 4), "height": round(height, 3), "eco_score": round(eco_score, 5)}


def _orientation_candidates(mesh: trimesh.Trimesh) -> List[Dict[str, Any]]:
    rotations = [
        ("Original", np.eye(4)),
        ("X +90°", trimesh.transformations.rotation_matrix(math.radians(90), [1, 0, 0])),
        ("X -90°", trimesh.transformations.rotation_matrix(math.radians(-90), [1, 0, 0])),
        ("Y +90°", trimesh.transformations.rotation_matrix(math.radians(90), [0, 1, 0])),
        ("Y -90°", trimesh.transformations.rotation_matrix(math.radians(-90), [0, 1, 0])),
        ("Z +90°", trimesh.transformations.rotation_matrix(math.radians(90), [0, 0, 1])),
    ]
    out = []
    for name, T in rotations:
        m = mesh.copy(); m.apply_transform(T); _translate_to_bed(m)
        out.append({"name": name, "matrix": T.tolist(), **_support_metrics(m)})
    return sorted(out, key=lambda x: x["eco_score"])


def _support_criticality(mesh: trimesh.Trimesh) -> np.ndarray:
    """Continuous 0..1 support-need score per triangle for the current bed orientation.

    The score is intentionally a printability heatmap rather than generated support geometry:
    downward-facing angle drives the score, while height above the bed slightly increases
    the consequence of a failed unsupported region.
    """
    normals=np.asarray(mesh.face_normals,dtype=float)
    centers=np.asarray(mesh.triangles_center,dtype=float)
    if len(normals)==0:
        return np.zeros(0,dtype=float)
    # 45 degree support threshold: horizontal underside = 1, printable/upward = 0.
    threshold=math.cos(math.radians(45.0))
    down=np.clip((-normals[:,2]-threshold)/max(1.0-threshold,1e-9),0.0,1.0)
    z=centers[:,2] if len(centers) else np.zeros(len(normals))
    zspan=max(float(np.ptp(z)),1e-9)
    zrel=np.clip((z-float(np.min(z)))/zspan,0.0,1.0)
    score=np.clip(down*(0.78+0.22*zrel),0.0,1.0)
    return score


def _predicted_stress_proxy(mesh: trimesh.Trimesh, intent: Optional[Dict[str, Any]]=None) -> np.ndarray:
    """Intent-aware qualitative stress concentration proxy (NOT FEA).

    It combines geometry extremity, face orientation relative to the described load,
    feature-scale complexity, and bending/moment-arm cues. It is intentionally labeled
    Predicted Stress in the UI until real fixed/load-face boundary conditions and FEA land.
    """
    normals=np.asarray(mesh.face_normals,dtype=float)
    areas=np.asarray(mesh.area_faces,dtype=float)
    centers=np.asarray(mesh.triangles_center,dtype=float)
    if len(normals)==0:
        return np.zeros(0,dtype=float)
    ext=np.maximum(np.asarray(mesh.extents,dtype=float),1e-9)
    centroid=np.asarray(mesh.centroid,dtype=float)
    rel=(centers-centroid)/ext
    radial=np.linalg.norm(rel,axis=1)
    radial=radial/max(float(radial.max()),1e-9)

    direction=(intent or {}).get('load_direction','-Z')
    vecs={'+X':np.array([1.,0.,0.]),'-X':np.array([-1.,0.,0.]),'+Y':np.array([0.,1.,0.]),'-Y':np.array([0.,-1.,0.]),'+Z':np.array([0.,0.,1.]),'-Z':np.array([0.,0.,-1.])}
    lv=vecs.get(str(direction).upper(),np.array([0.,0.,-1.]))
    # Faces whose normals align with the applied load are likely load-transfer/contact surfaces.
    load_alignment=np.abs(normals@lv)
    # Moment arm along the load direction highlights geometry farther from the neutral region.
    proj=np.abs(rel@lv)
    proj=proj/max(float(proj.max()),1e-9)
    # Small triangles often occur around holes, fillets, embossed detail and geometric discontinuities.
    med=max(float(np.median(areas)) if len(areas) else 1.0,1e-12)
    detail=np.clip(1.0-areas/(med*2.5),0.0,1.0)
    score=np.clip(0.30*radial+0.28*proj+0.24*load_alignment+0.18*detail,0.0,1.0)

    # Functional/structural descriptions sharpen the high-stress end of the display.
    rec=(intent or {}).get('strength_recommendation') or {}
    level=str(rec.get('level','FUNCTIONAL')).upper()
    gamma={'LIGHT':1.18,'FUNCTIONAL':1.0,'STRUCTURAL':0.86,'HEAVY':0.75}.get(level,1.0)
    score=np.power(score,gamma)
    return np.clip(score,0.0,1.0)


def _face_analysis(mesh: trimesh.Trimesh, intent: Optional[Dict[str, Any]]=None) -> Dict[str, Any]:
    areas=np.asarray(mesh.area_faces)
    support=_support_criticality(mesh)
    stress=_predicted_stress_proxy(mesh,intent)
    med=float(np.median(areas)) if len(areas) else 0.0
    thin=np.where(areas < max(med*.35,1e-9),1.0,0.0)
    return {
        "predicted_stress":np.round(stress,4).tolist(),
        "stress_proxy":np.round(stress,4).tolist(),
        "support_criticality":np.round(support,4).tolist(),
        "overhang_mask":np.where(support>0.01,1,0).astype(int).tolist(),
        "thin_mask":thin.astype(int).tolist(),
        "stress_model":"Intent-aware qualitative proxy; not finite element analysis"
    }


def _segment_cylinder(a: np.ndarray, b: np.ndarray, radius: float, sections: int = 10) -> Optional[trimesh.Trimesh]:
    a=np.asarray(a,dtype=float); b=np.asarray(b,dtype=float)
    vec=b-a; length=float(np.linalg.norm(vec))
    if length < 0.15 or radius <= 0:
        return None
    m=trimesh.creation.cylinder(radius=float(radius), height=length, sections=sections)
    T=trimesh.geometry.align_vectors([0,0,1], vec/length)
    if T is None: T=np.eye(4)
    m.apply_transform(T); m.apply_translation((a+b)/2.0)
    return m


def _segment_taper(a: np.ndarray, b: np.ndarray, r0: float, r1: float, sections: int = 10) -> Optional[trimesh.Trimesh]:
    # Trimesh cone uses radius at the base and a point at the top. For a light
    # tapered strut, approximate a frustum with stacked cylinders whose radius
    # decreases smoothly. This is robust and keeps dependencies minimal.
    a=np.asarray(a,dtype=float); b=np.asarray(b,dtype=float)
    vec=b-a; length=float(np.linalg.norm(vec))
    if length < 0.25: return None
    pieces=[]; n=4
    for i in range(n):
        t0=i/n; t1=(i+1)/n
        p0=a+vec*t0; p1=a+vec*t1
        r=(r0*(1-(t0+t1)/2.0)+r1*((t0+t1)/2.0))
        c=_segment_cylinder(p0,p1,max(float(r),0.18),sections)
        if c is not None: pieces.append(c)
    return trimesh.util.concatenate(pieces) if pieces else None


def _lowest_surface_hit_at_xy(mesh: trimesh.Trimesh, x: float, y: float) -> Optional[Dict[str, Any]]:
    """Return the lowest model-surface Z intersected by a vertical line at XY.

    Uses the XY projection of triangles, so it works without optional ray/rtree
    packages. Degenerate near-vertical triangles are ignored because they do not
    define a stable underside height for build-plate supports.
    """
    tri=np.asarray(mesh.triangles,dtype=float)
    if len(tri)==0: return None
    minx=np.min(tri[:,:,0],axis=1); maxx=np.max(tri[:,:,0],axis=1)
    miny=np.min(tri[:,:,1],axis=1); maxy=np.max(tri[:,:,1],axis=1)
    eps=1e-7
    mask=(x>=minx-eps)&(x<=maxx+eps)&(y>=miny-eps)&(y<=maxy+eps)
    t=tri[mask]
    if len(t)==0: return None
    ax=t[:,0,0]; ay=t[:,0,1]; bx=t[:,1,0]; by=t[:,1,1]; cx=t[:,2,0]; cy=t[:,2,1]
    den=(by-cy)*(ax-cx)+(cx-bx)*(ay-cy)
    good=np.abs(den)>1e-10
    if not np.any(good): return None
    t=t[good]; den=den[good]; ax=ax[good]; ay=ay[good]; bx=bx[good]; by=by[good]; cx=cx[good]; cy=cy[good]
    w1=((by-cy)*(x-cx)+(cx-bx)*(y-cy))/den
    w2=((cy-ay)*(x-cx)+(ax-cx)*(y-cy))/den
    w3=1.0-w1-w2
    inside=(w1>=-1e-7)&(w2>=-1e-7)&(w3>=-1e-7)
    if not np.any(inside): return None
    t=t[inside]; w1=w1[inside]; w2=w2[inside]; w3=w3[inside]
    z=w1*t[:,0,2]+w2*t[:,1,2]+w3*t[:,2,2]
    finite=np.isfinite(z)
    if not np.any(finite): return None
    z=z[finite]
    # Recover original face indices after the bounding-box/degeneracy/inside masks.
    face_ids=np.where(mask)[0][good][inside][finite]
    k=int(np.argmin(z))
    fi=int(face_ids[k])
    return {"z": float(z[k]), "face": fi, "normal": np.asarray(mesh.face_normals[fi],dtype=float)}


def _lowest_surface_z_at_xy(mesh: trimesh.Trimesh, x: float, y: float) -> Optional[float]:
    hit=_lowest_surface_hit_at_xy(mesh,x,y)
    return None if hit is None else float(hit["z"])


def _vertical_column_clear(mesh: trimesh.Trimesh, x: float, y: float, target_surface_z: float, radius: float=0.42) -> bool:
    """Check the narrow printable support shaft, not a wide imaginary pillar.

    v0.6 sampled a 1.25 mm radius footprint around every target. On curved
    surfaces (especially a Benchy hull) nearby triangles naturally sit lower,
    so almost every legitimate support was falsely classified as a collision.
    Real slicer supports narrow substantially near the interface, so v0.7 uses
    a small shaft-clearance radius and only rejects geometry that blocks the
    shaft substantially below the intended contact.
    """
    samples=[(0.0,0.0)]
    for a in np.linspace(0,2*math.pi,6,endpoint=False):
        samples.append((math.cos(a)*radius,math.sin(a)*radius))
    for dx,dy in samples:
        z=_lowest_surface_z_at_xy(mesh,x+dx,y+dy)
        if z is not None and z < target_surface_z-1.05:
            return False
    return True


def _make_support_rib(mesh: trimesh.Trimesh, contacts: List[Dict[str, Any]], gap: float=0.28) -> Optional[trimesh.Trimesh]:
    """Create one narrow hull-style support rib when the geometry strongly suits it.

    This is intentionally conservative. It is only used for a broad, smooth,
    sloped/curved underside with enough height variation. Flat roofs and scattered
    overhangs continue to use slicer-like micro pillars.
    """
    if len(contacts)<10: return None
    pts=np.array([c['p'] for c in contacts],dtype=float)
    ns=np.array([c['n'] for c in contacts],dtype=float)
    if len(pts)<10: return None
    xy=pts[:,:2]
    span=np.ptp(xy,axis=0)
    if float(np.max(span))<18.0: return None
    zrange=float(np.ptp(pts[:,2]))
    # Hull-like shells normally vary in height and surface angle. A flat plate
    # should not receive a single rib because point/pillar support is safer.
    mean_down=float(np.mean(np.clip(-ns[:,2],0,1)))
    normal_var=float(np.std(ns[:,2]))
    if zrange<2.5 or not (0.25<mean_down<0.985):
        return None

    center=np.mean(xy,axis=0)
    X=xy-center
    cov=(X.T@X)/max(len(X),1)
    vals,vecs=np.linalg.eigh(cov)
    axis=vecs[:,int(np.argmax(vals))]
    axis=axis/max(float(np.linalg.norm(axis)),1e-9)
    perp=np.array([-axis[1],axis[0]])
    proj=X@axis
    lo=float(np.percentile(proj,8)); hi=float(np.percentile(proj,92))
    if hi-lo<14.0: return None

    width=0.9
    samples=18
    sections=[]
    for t in np.linspace(lo,hi,samples):
        cxy=center+axis*t
        left=cxy-perp*width/2.0; right=cxy+perp*width/2.0
        zl=_lowest_surface_z_at_xy(mesh,float(left[0]),float(left[1]))
        zr=_lowest_surface_z_at_xy(mesh,float(right[0]),float(right[1]))
        if zl is None or zr is None: sections.append(None); continue
        top=min(zl,zr)-gap-0.18
        if top<1.6: sections.append(None); continue
        sections.append((left,right,float(top)))

    # Keep the longest contiguous valid run only; this prevents bridging through
    # holes/open water under complex parts.
    best=[]; cur=[]
    for sec in sections+[None]:
        if sec is not None: cur.append(sec)
        else:
            if len(cur)>len(best): best=cur
            cur=[]
    if len(best)<6: return None

    verts=[]
    base_z=0.12
    for left,right,top in best:
        verts.extend([[left[0],left[1],base_z],[right[0],right[1],base_z],
                      [left[0],left[1],top],[right[0],right[1],top]])
    faces=[]
    n=len(best)
    for i in range(n-1):
        a=4*i; b=4*(i+1)
        # sides
        faces += [[a,b,b+2],[a,b+2,a+2], [a+1,a+3,b+3],[a+1,b+3,b+1],
                  [a+2,b+2,b+3],[a+2,b+3,a+3], [a,b+1,b],[a,a+1,b+1]]
    faces += [[0,2,3],[0,3,1], [4*(n-1),4*(n-1)+1,4*(n-1)+3],[4*(n-1),4*(n-1)+3,4*(n-1)+2]]
    rib=trimesh.Trimesh(vertices=np.asarray(verts),faces=np.asarray(faces,dtype=int),process=False)
    try: rib.remove_unreferenced_vertices()
    except Exception: pass
    return rib


def _adaptive_supports(mesh: trimesh.Trimesh, overhang_angle_deg: float = 48.0) -> Dict[str, Any]:
    """Generate build-plate-reachable lightweight supports from the underside envelope.

    Key v0.7 fix: support targets are resolved to the LOWEST model surface at
    each sampled XY location. This is the physically reachable underside from
    the print bed. v0.6 instead sampled arbitrary downward faces and then
    rejected them whenever any nearby triangle was lower, which incorrectly
    eliminated curved hulls and could report zero supports while the global
    support-risk metric remained non-zero.
    """
    m=mesh.copy(); _translate_to_bed(m)
    centers=np.asarray(m.triangles_center,dtype=float)
    normals=np.asarray(m.face_normals,dtype=float)
    areas=np.asarray(m.area_faces,dtype=float)
    if len(centers)==0:
        raise HTTPException(status_code=400,detail='No faces available for support analysis.')

    max_dim=max(float(np.max(m.extents)),1.0); max_z=max(float(m.bounds[1][2]),1.0)
    # A face needs support when its outward normal has a sufficiently strong
    # downward component. 48° remains the UI default, but the envelope test
    # below decides whether the surface is actually reachable from the bed.
    down_thresh=max(0.10, math.sin(math.radians(max(1.0,90.0-overhang_angle_deg))))
    downness=np.clip(-normals[:,2],0.0,1.0)
    candidate=(downness > down_thresh) & (centers[:,2] > 0.55)
    idx=np.where(candidate)[0]
    if len(idx)==0:
        return {'support_mesh': {'vertices': [], 'faces': []}, 'contacts':0,'groups':0,
                'adaptive_volume_mm3':0.0,'default_proxy_volume_mm3':0.0,'tree_proxy_volume_mm3':0.0,
                'vs_default_saving_pct':0.0,'vs_tree_saving_pct':0.0,'support_mass_g_pla':0.0,
                'overhang_angle_deg':overhang_angle_deg,'micro_pillars':0,'rib_supports':0,
                'skipped_occluded':0,'note':'No downward overhang faces exceeded the support threshold.'}

    # Sample candidate overhang area densely enough that large STL triangles do
    # not collapse to a single centroid. Then use those XY locations to query
    # the true bed-visible underside envelope.
    spacing=float(np.clip(max_dim/24.0, 2.0, 4.2))
    weights=np.zeros(len(m.faces),dtype=float)
    weights[idx]=areas[idx]*(0.55+0.45*downness[idx])
    sample_count=int(np.clip(max(float(np.sum(areas[idx]))/(spacing*spacing)*7.0,220),220,1500))
    sampled_pts,sampled_faces=trimesh.sample.sample_surface(m,sample_count,face_weight=weights,seed=42)

    cells={}
    for c,fi in zip(sampled_pts,sampled_faces):
        if not candidate[int(fi)]: continue
        key=(int(math.floor(c[0]/spacing)),int(math.floor(c[1]/spacing)))
        # Resolve to the lowest actual surface at this XY. This prevents supports
        # from targeting an upper deck through the hull while retaining the hull
        # itself as a perfectly valid support target.
        hit=_lowest_surface_hit_at_xy(m,float(c[0]),float(c[1]))
        if hit is None: continue
        hz=float(hit['z']); hfi=int(hit['face']); hn=np.asarray(hit['normal'],dtype=float)
        hdown=max(0.0,float(-hn[2]))
        if hz <= 0.58 or hdown <= down_thresh*0.78:
            continue
        score=hdown*(0.82+0.18*hz/max_z)
        p=np.array([float(c[0]),float(c[1]),hz],dtype=float)
        if key not in cells or score>cells[key][0]:
            cells[key]=(score,p,hfi,hn)

    chosen=sorted(cells.values(),key=lambda z:z[0],reverse=True)[:180]

    # Keep only locations where a narrow support shaft can reach the envelope.
    # Unlike v0.6, we do NOT reject a hull merely because neighboring points on
    # the same curved surface are lower.
    visible=[]; skipped=0
    for score,p0,fi,hn in chosen:
        p=p0.copy(); target=float(p[2])
        if not _vertical_column_clear(m,float(p[0]),float(p[1]),target,0.42):
            skipped+=1; continue
        p[2]=max(0.42,target-0.26)
        visible.append({'p':p,'surface_z':target,'w':float(max(areas[fi]*max(-hn[2],0.05),1e-6)),
                        'face':int(fi),'n':hn.copy()})

    if not visible:
        return {'support_mesh': {'vertices': [], 'faces': []}, 'contacts':0,'groups':0,
                'adaptive_volume_mm3':0.0,'default_proxy_volume_mm3':0.0,'tree_proxy_volume_mm3':0.0,
                'vs_default_saving_pct':0.0,'vs_tree_saving_pct':0.0,'support_mass_g_pla':0.0,
                'overhang_angle_deg':overhang_angle_deg,'micro_pillars':0,'rib_supports':0,
                'skipped_occluded':skipped,'note':'Overhangs exist, but the current support shafts could not reach them from the build plate.'}

    pieces=[]
    # One narrow hull-style rib is still optional for a broad curved/sloped shell.
    # It is generated only from the bed-visible envelope contacts.
    rib=_make_support_rib(m,visible)
    rib_count=0
    if rib is not None and len(rib.faces):
        pieces.append(rib); rib_count=1

    pillar_count=0; default_vol=0.0; tree_vol=0.0
    r_default=1.45; r_tree=0.90
    for c in visible:
        p=c['p']; h=float(p[2])
        default_vol += math.pi*r_default*r_default*h
        tree_vol += math.pi*r_tree*r_tree*h
        # If the conservative rib already occupies this XY footprint, avoid a
        # duplicate micro-pillar.
        if rib is not None:
            rb=np.asarray(rib.bounds)
            if rb[0,0]-1.0<=p[0]<=rb[1,0]+1.0 and rb[0,1]-1.0<=p[1]<=rb[1,1]+1.0:
                continue
        if h<0.85: continue
        # Slicer-like stack: small bed foot, narrow shaft, tapered interface and
        # a tiny cap that stops below the model.
        foot=trimesh.creation.cylinder(radius=0.95,height=0.24,sections=10)
        foot.apply_translation([p[0],p[1],0.12]); pieces.append(foot)
        trunk_top=max(0.42,h-0.72)
        trunk=_segment_taper(np.array([p[0],p[1],0.24]),np.array([p[0],p[1],trunk_top]),0.46,0.38,9)
        if trunk is not None: pieces.append(trunk)
        tip=_segment_taper(np.array([p[0],p[1],trunk_top]),np.array([p[0],p[1],h]),0.38,0.22,9)
        if tip is not None: pieces.append(tip)
        cap=trimesh.creation.cylinder(radius=0.50,height=0.12,sections=10)
        cap.apply_translation([p[0],p[1],max(0.06,h-0.06)]); pieces.append(cap)
        pillar_count+=1

    if pieces:
        sm=trimesh.util.concatenate(pieces)
        try: sm.remove_unreferenced_vertices()
        except Exception: pass
    else:
        sm=trimesh.Trimesh(vertices=np.empty((0,3)),faces=np.empty((0,3),dtype=int),process=False)

    adaptive=0.0
    for q in pieces:
        try: adaptive += abs(float(q.volume))
        except Exception: pass
    default=max(float(default_vol),adaptive); tree=max(float(tree_vol),adaptive)
    return {
        'support_mesh':_mesh_to_json(sm) if len(sm.faces) else {'vertices':[],'faces':[]},
        'contacts':len(visible),'groups':pillar_count+rib_count,
        'micro_pillars':pillar_count,'rib_supports':rib_count,'skipped_occluded':skipped,
        'adaptive_volume_mm3':round(adaptive,1),'default_proxy_volume_mm3':round(default,1),
        'tree_proxy_volume_mm3':round(tree,1),
        'vs_default_saving_pct':round(max(0.0,(1-adaptive/max(default,1e-9))*100),1),
        'vs_tree_saving_pct':round(max(0.0,(1-adaptive/max(tree,1e-9))*100),1),
        'support_mass_g_pla':round(adaptive/1000.0*1.24,2),
        'overhang_angle_deg':round(float(overhang_angle_deg),1),
        'note':('v0.7 underside-envelope supports: targets are the lowest bed-visible surface at each XY, '
                'so curved hull supports are retained while upper surfaces hidden behind the model are rejected. '
                'Prototype Z-gap and support thickness still require slicer/test-print validation.')
    }


def _estimate_mass(mesh: trimesh.Trimesh, density_g_cm3: float=1.24) -> float:
    try:
        v=abs(float(mesh.volume))
        return round((v/1000.0)*density_g_cm3,2) if math.isfinite(v) else 0.0
    except Exception: return 0.0


def _mesh_to_json(mesh: trimesh.Trimesh) -> Dict[str, Any]:
    # IMPORTANT: do not simplify the interactive viewer mesh. Face picking in the
    # browser sends a triangle index back to the backend, so the viewer and backend
    # must use the exact same face ordering.
    m = mesh.copy()
    return {
        "vertices": np.round(np.asarray(m.vertices), 5).reshape(-1).tolist(),
        "faces": np.asarray(m.faces, dtype=int).reshape(-1).tolist(),
    }

def _geometry_summary(mesh: trimesh.Trimesh) -> Dict[str, Any]:
    dims=[round(float(x),2) for x in mesh.extents]; watertight=bool(mesh.is_watertight)
    return {"vertices":int(len(mesh.vertices)),"faces":int(len(mesh.faces)),"dimensions_mm":dims,"surface_area_mm2":round(float(mesh.area),2),"volume_mm3":round(abs(float(mesh.volume)),2) if watertight else None,"watertight":watertight,"solid_mass_proxy_g_pla":_estimate_mass(mesh)}


def _build_options(mesh: trimesh.Trimesh, orientations: List[Dict[str, Any]], intent: Optional[Dict[str,Any]]=None) -> List[Dict[str, Any]]:
    solid_mass=_estimate_mass(mesh); baseline=max(solid_mass*.30,1.0); best_support=orientations[0]["support_ratio"] if orientations else 0.0
    rec=(intent or {}).get("strength_recommendation") or _strength_recommendation("",None,[])
    base_w=int(rec["wall_loops"]); base_i=int(rec["infill_density_pct"]); base_top=int(rec["top_shell_layers"]); base_bottom=int(rec["bottom_shell_layers"])
    variants=[
        ("eco","Eco",max(2,base_w-1),max(6,base_i-8),max(3,base_top-1),max(3,base_bottom-1),max(1.4,rec["target_safety_factor"]-.4),.68,.63),
        ("balanced","Balanced",base_w,base_i,base_top,base_bottom,rec["target_safety_factor"],.80,.78),
        ("strength","Maximum Strength",min(7,base_w+2),min(60,base_i+15),min(8,base_top+2),min(8,base_bottom+2),rec["target_safety_factor"]+1.0,.98,.96),
    ]
    out=[]
    for key,label,walls,infill,top,bottom,sf,mf,tf in variants:
        material=baseline*mf; support=baseline*best_support*.30*mf; total=material+support
        base_time=max(35.0,baseline*2.45); time_min=base_time*tf+support*1.2; energy=(time_min/60.0)*.105*(.95+mf*.10)
        out.append({
            "key":key,"label":label,"predicted_material_g":round(total,1),"predicted_support_g":round(support,1),
            "predicted_time_min":round(time_min),"predicted_energy_kwh":round(energy,3),
            "relative_material_saving_pct":round(max(0.0,(1-total/max(baseline*1.1,1e-6))*100),1),
            "safety_factor_target":round(sf,1),"wall_strategy":f"{walls} wall loops","infill_strategy":f"{infill}% {rec['infill_pattern']}",
            "wall_loops":walls,"infill_density_pct":infill,"infill_pattern":rec["infill_pattern"],
            "top_shell_layers":top,"bottom_shell_layers":bottom,
            "strength_class":rec["level"],"strength_confidence":"Intent-derived process settings — verify with FEA/load test"
        })
    return out

def _preview_payload(session_id: str, mesh: trimesh.Trimesh, filename: str, orientation_label: str) -> Dict[str, Any]:
    orientations=_orientation_candidates(mesh); best=orientations[0] if orientations else _support_metrics(mesh)
    preview_analysis=_face_analysis(mesh,None)
    # Stress is intentionally withheld until the user's design intent has been analyzed.
    preview_analysis.pop("predicted_stress",None); preview_analysis.pop("stress_proxy",None)
    return {"session_id":session_id,"filename":filename,"orientation_label":orientation_label,"geometry":_geometry_summary(mesh),"viewer_mesh":_mesh_to_json(mesh),"support":_support_metrics(mesh),"analysis":preview_analysis,"auto_orientation":best}


@app.get("/", response_class=HTMLResponse)
def index() -> str:
    return (TEMPLATE_DIR / "index.html").read_text(encoding="utf-8")


@app.get("/api/health")
def health() -> Dict[str,str]: return {"status":"ok","app":"AlphaSlice","version":"1.24.0"}


@app.post("/api/preview")
async def preview(file: UploadFile=File(...)) -> JSONResponse:
    raw=await file.read()
    if len(raw)>70*1024*1024: raise HTTPException(status_code=413,detail="Model is larger than the 70 MB prototype limit.")
    mesh=_load_mesh(file.filename or "model.stl",raw); _translate_to_bed(mesh)
    sid=_new_id(); SESSIONS[sid]={"kind":"preview","filename":file.filename or "model.stl","original_mesh":mesh.copy(),"mesh":mesh,"orientation_label":"Imported orientation"}
    return JSONResponse(_preview_payload(sid,mesh,file.filename or "model.stl","Imported orientation"))


@app.post("/api/orient")
def orient(req: OrientRequest) -> JSONResponse:
    s=SESSIONS.get(req.session_id)
    if not s or s.get("kind")!="preview": raise HTTPException(status_code=404,detail="Preview session expired. Re-import the model.")
    mode=req.mode.lower()
    if mode=="reset":
        mesh=s["original_mesh"].copy(); _translate_to_bed(mesh); label="Imported orientation"
    elif mode=="auto":
        mesh=s["mesh"].copy(); candidates=_orientation_candidates(mesh); best=candidates[0]
        mesh.apply_transform(np.asarray(best["matrix"],dtype=float)); _translate_to_bed(mesh); label=f"Auto: {best['name']}"
    elif mode=="face":
        mesh=s["mesh"].copy()
        if req.face_index is None or req.face_index<0 or req.face_index>=len(mesh.faces): raise HTTPException(status_code=400,detail="Select a model face first.")
        normal=np.asarray(mesh.face_normals[req.face_index],dtype=float)
        T=_rotation_from_vectors(normal,np.array([0.0,0.0,-1.0])); mesh.apply_transform(T); _translate_to_bed(mesh); label=f"Selected face #{req.face_index+1} on bed"
    else: raise HTTPException(status_code=400,detail="Unknown orientation mode.")
    s["mesh"]=mesh; s["orientation_label"]=label; s.pop("adaptive_supports",None)
    return JSONResponse(_preview_payload(req.session_id,mesh,s["filename"],label))




def _find_orcaslicer() -> Optional[str]:
    candidates=[]
    if os.name == "nt":
        env=os.environ
        for root in [env.get("PROGRAMFILES"), env.get("PROGRAMFILES(X86)"), env.get("LOCALAPPDATA")]:
            if not root: continue
            candidates.extend([
                Path(root)/"OrcaSlicer"/"orca-slicer.exe",
                Path(root)/"OrcaSlicer"/"OrcaSlicer.exe",
                Path(root)/"Programs"/"OrcaSlicer"/"orca-slicer.exe",
                Path(root)/"Programs"/"OrcaSlicer"/"OrcaSlicer.exe",
            ])
    else:
        for name in ["orca-slicer", "OrcaSlicer", "orcaslicer"]:
            found=shutil.which(name)
            if found: candidates.append(Path(found))
        candidates.append(Path('/Applications/OrcaSlicer.app/Contents/MacOS/OrcaSlicer'))
    for c in candidates:
        try:
            if c.exists(): return str(c)
        except Exception:
            pass
    return None


class OrcaOpenRequest(BaseModel):
    session_id: str
    executable: Optional[str] = None
    analysis_session_id: Optional[str] = None
    option: str = "balanced"




class PluginHeartbeatRequest(BaseModel):
    plugin_version: Optional[str] = None


class PluginSyncRequest(BaseModel):
    analysis_session_id: str
    option: str = "balanced"


def _orca_data_dir(executable: Optional[str] = None) -> Path:
    # OrcaSlicer official default data directory. Portable builds may instead
    # use a sibling data_dir folder; prefer that when present.
    if executable:
        try:
            sibling = Path(executable).resolve().parent / "data_dir"
            if sibling.exists():
                return sibling
        except Exception:
            pass
    if os.name == "nt":
        appdata = os.environ.get("APPDATA")
        if appdata:
            return Path(appdata) / "OrcaSlicer"
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "OrcaSlicer"
    return Path.home() / ".config" / "OrcaSlicer"


def _plugin_source() -> Path:
    return BASE_DIR.parent / "orca_plugin" / "EcoSliceBridge" / "ecoslice_bridge.py"


def _plugin_target(executable: Optional[str] = None) -> Path:
    return _orca_data_dir(executable) / "orca_plugins" / "EcoSliceBridge" / "ecoslice_bridge.py"


def _orcaslicer_version(executable: Optional[str]) -> Optional[str]:
    if not executable or not Path(executable).exists():
        return None
    if os.name == "nt":
        try:
            ps = [
                "powershell", "-NoProfile", "-Command",
                f"(Get-Item -LiteralPath '{str(executable).replace(chr(39), chr(39)*2)}').VersionInfo.ProductVersion"
            ]
            out = subprocess.check_output(ps, text=True, timeout=4, stderr=subprocess.DEVNULL).strip()
            return out or None
        except Exception:
            return None
    return None


def _plugin_connected() -> bool:
    return (time.time() - float(PLUGIN_STATE.get("last_heartbeat") or 0.0)) < 20.0


@app.post("/api/plugin/heartbeat")
def plugin_heartbeat(req: PluginHeartbeatRequest) -> JSONResponse:
    PLUGIN_STATE["last_heartbeat"] = time.time()
    PLUGIN_STATE["plugin_version"] = req.plugin_version
    return JSONResponse({"ok": True})


@app.get("/api/plugin/recommendation")
def plugin_recommendation() -> JSONResponse:
    return JSONResponse({
        "connected": _plugin_connected(),
        "plugin_version": PLUGIN_STATE.get("plugin_version"),
        "recommendation": PLUGIN_STATE.get("recommendation"),
    })


@app.post("/api/plugin/sync")
def plugin_sync(req: PluginSyncRequest) -> JSONResponse:
    a = SESSIONS.get(req.analysis_session_id)
    if not a or a.get("kind") != "analysis":
        raise HTTPException(status_code=404, detail="Analysis session expired. Run Analyze & Optimize again.")
    opt = next((x for x in a.get("options", []) if x.get("key") == req.option.lower()), None)
    if not opt:
        raise HTTPException(status_code=400, detail="Unknown AlphaSlice option.")
    state = dict(opt)
    state["support_mode"] = "Tree (auto) / Organic"
    state["synced_at"] = time.time()
    PLUGIN_STATE["recommendation"] = state
    return JSONResponse({"ok": True, "connected": _plugin_connected(), "recommendation": state})


@app.get("/api/plugin/status")
def plugin_status(executable: Optional[str] = None) -> JSONResponse:
    exe = (executable or "").strip() or _find_orcaslicer()
    target = _plugin_target(exe)
    return JSONResponse({
        "orca_found": bool(exe),
        "orca_path": exe,
        "orca_version": _orcaslicer_version(exe),
        "data_dir": str(_orca_data_dir(exe)),
        "plugin_path": str(target),
        "installed": target.exists(),
        "connected": _plugin_connected(),
        "plugin_version": PLUGIN_STATE.get("plugin_version"),
        "requires": "OrcaSlicer Nightly or release > 2.4.2",
    })


@app.post("/api/plugin/install")
def plugin_install(executable: Optional[str] = None) -> JSONResponse:
    exe = (executable or "").strip() or _find_orcaslicer()
    if not exe:
        raise HTTPException(status_code=400, detail="OrcaSlicer was not found. Detect OrcaSlicer or provide its executable path first.")
    src = _plugin_source()
    if not src.exists():
        raise HTTPException(status_code=500, detail="AlphaSlice plugin payload is missing from this build.")
    target = _plugin_target(exe)
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, target)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Could not install plugin: {exc}")
    return JSONResponse({
        "ok": True,
        "installed": True,
        "plugin_path": str(target),
        "data_dir": str(_orca_data_dir(exe)),
        "orca_version": _orcaslicer_version(exe),
        "message": "AlphaSlice Bridge was side-loaded. Restart OrcaSlicer, then open File > Plugins and activate AlphaSlice Bridge if Orca does not activate it automatically.",
    })


@app.get("/api/orca/status")
def orca_status() -> JSONResponse:
    exe=_find_orcaslicer()
    payload={"found": bool(exe), "path": exe, "environment": None}
    if exe:
        try:
            data_dir=_orca_data_dir(exe)
            selections=_orca_read_current_selections(data_dir, exe)
            machine=_orca_find_profile(data_dir,selections.get("printer"),"printer",exe)
            if not machine:
                machine=_orca_infer_machine_without_config(data_dir,exe)
                if machine and not selections.get("printer"):
                    try:
                        mobj=json.loads(machine.read_text(encoding="utf-8-sig",errors="replace"))
                        selections["printer"]=str(mobj.get("name") or machine.stem)
                    except Exception: pass
            process=_orca_find_profile(data_dir,selections.get("process"),"process",exe)
            if machine and not process and selections.get("printer"):
                process=_orca_find_compatible_process(data_dir,selections["printer"],exe)
                if process and (not selections.get("process") or selections.get("process","").lower()=="default"):
                    try:
                        pobj=json.loads(process.read_text(encoding="utf-8-sig",errors="replace"))
                        selections["process"]=str(pobj.get("name") or process.stem)
                    except Exception: pass
            payload["environment"]={
                "ready": bool(machine and process),
                "printer": selections.get("printer"),
                "process": selections.get("process"),
                "filaments": selections.get("filaments") or [],
                "config_source": selections.get("source"),
                "machine_profile_found": bool(machine),
                "process_profile_found": bool(process),
                "discovery": selections.get("discovery") or [],
            }
        except Exception as exc:
            payload["environment"]={"ready":False,"error":f"{type(exc).__name__}: {exc}"}
    return JSONResponse(payload)




def _orca_profile_roots(data_dir: Path, exe: Optional[str] = None) -> list[Path]:
    """Return every profile root AlphaSlice can discover automatically.

    Orca installations may keep bundled profiles beside the executable while
    user/cloud profiles live under AppData.  Never require the user to locate
    either manually.
    """
    roots: list[Path] = []
    candidates = [data_dir / "user", data_dir / "system", data_dir / "profiles"]
    if exe:
        ep = Path(exe).resolve().parent
        candidates += [ep / "resources" / "profiles", ep.parent / "resources" / "profiles"]
    seen=set()
    for r in candidates:
        try:
            rr=r.resolve()
        except Exception:
            rr=r
        key=str(rr).lower()
        if key not in seen and r.exists():
            roots.append(r); seen.add(key)
    return roots


def _orca_build_profile_index(data_dir: Path, exe: Optional[str] = None) -> Dict[str, list[Dict[str, Any]]]:
    """Index Orca machine/process/filament JSONs by their human preset name."""
    out={"printer": [], "process": [], "filament": []}
    kind_dirs={"machine":"printer", "process":"process", "filament":"filament"}
    for root in _orca_profile_roots(data_dir, exe):
        try:
            files=list(root.rglob("*.json"))
        except Exception:
            continue
        for f in files:
            lowparts={x.lower() for x in f.parts}
            kind=None
            for token,k in kind_dirs.items():
                if token in lowparts:
                    kind=k; break
            if not kind:
                # Some vendor bundles do not have a clean folder token; infer by JSON type.
                pass
            try:
                if f.stat().st_size > 2_000_000: continue
                obj=json.loads(f.read_text(encoding="utf-8-sig", errors="replace"))
            except Exception:
                continue
            typ=str(obj.get("type", "")).lower()
            if not kind:
                if "machine" in typ or "printer" in typ: kind="printer"
                elif "process" in typ or "print" == typ: kind="process"
                elif "filament" in typ: kind="filament"
            if not kind: continue
            name=str(obj.get("name") or f.stem).strip()
            if not name: continue
            out[kind].append({"name":name, "path":f, "obj":obj})
    return out


def _orca_config_candidates(data_dir: Path) -> list[Path]:
    """Find Orca state/config files without assuming one filename or cloud layout."""
    preferred=[data_dir/"OrcaSlicer.conf", data_dir/"config.ini", data_dir/"OrcaSlicer.ini"]
    found=[]; seen=set()
    for f in preferred:
        if f.exists(): found.append(f); seen.add(str(f).lower())
    try:
        for f in data_dir.rglob("*"):
            if not f.is_file(): continue
            if str(f).lower() in seen: continue
            if f.suffix.lower() not in {".conf",".ini",".json",".cfg",".txt"}: continue
            try:
                if f.stat().st_size > 5_000_000: continue
            except Exception: continue
            nm=f.name.lower()
            # Favor application/preset/state files; avoid scanning giant logs/cache trees.
            if any(x in {p.lower() for p in f.parts} for x in ["cache","logs","log"]):
                continue
            if any(k in nm for k in ["orca","config","preset","app","state","setting"]):
                found.append(f); seen.add(str(f).lower())
    except Exception:
        pass
    def score(f: Path):
        n=f.name.lower(); s=0
        if n=="orcaslicer.conf": s+=100
        if "config" in n: s+=40
        if "preset" in n: s+=25
        try: s += min(20, int(f.stat().st_mtime/1e8)%20)
        except Exception: pass
        return s
    return sorted(found, key=score, reverse=True)


def _orca_read_current_selections(data_dir: Path, exe: Optional[str] = None) -> Dict[str, Any]:
    """Zero-config discovery of Orca's active environment.

    We first parse known structured layouts.  If Orca changes its serialization,
    AlphaSlice then scans Orca's own state files for exact installed preset names,
    so the user never has to browse AppData or identify a UUID folder.
    """
    result: Dict[str, Any] = {"printer":None,"process":None,"filaments":[],"source":None,"layout":None,"discovery":[]}
    index=_orca_build_profile_index(data_dir, exe)

    def clean(v):
        if isinstance(v,str):
            v=v.strip().strip('"')
            return v or None
        return None

    def add_fil(v):
        cv=clean(v)
        if cv and cv not in result["filaments"]: result["filaments"].append(cv)

    def harvest_mapping(obj: Any, source: str):
        if not isinstance(obj,dict): return
        presets=obj.get("presets")
        if isinstance(presets,dict):
            result["printer"] = clean(presets.get("printer") or presets.get("printer_preset") or presets.get("printer_settings_id")) or result["printer"]
            result["process"] = clean(presets.get("print") or presets.get("process") or presets.get("print_preset") or presets.get("print_settings_id")) or result["process"]
            for k,v in presets.items():
                if k=="filament" or k.startswith("filament_"): add_fil(v)
        snapshots=obj.get("orca_presets")
        if isinstance(snapshots,list) and snapshots:
            chosen=None
            if result["printer"]:
                chosen=next((x for x in snapshots if isinstance(x,dict) and clean(x.get("machine"))==result["printer"]),None)
            if chosen is None: chosen=next((x for x in reversed(snapshots) if isinstance(x,dict)),None)
            if isinstance(chosen,dict):
                result["printer"] = clean(chosen.get("machine") or chosen.get("printer")) or result["printer"]
                result["process"] = clean(chosen.get("process") or chosen.get("print") or chosen.get("print_settings_id")) or result["process"]
                add_fil(chosen.get("filament") or chosen.get("filament_settings_id"))
                for k,v in sorted(chosen.items()):
                    if k.startswith("filament_"): add_fil(v)
                result["layout"]="orca_presets"
        appsec=obj.get("app")
        if isinstance(appsec,dict):
            vals=appsec.get("filament_presets")
            if isinstance(vals,list):
                for v in vals: add_fil(v)
        # Recursive pass catches changed nesting without knowing Orca's exact schema.
        keymap={
            "printer":"printer", "printer_preset":"printer", "printer_settings_id":"printer",
            "machine":"printer", "machine_preset":"printer",
            "process":"process", "print":"process", "print_preset":"process", "print_settings_id":"process",
        }
        for k,v in obj.items():
            lk=str(k).lower()
            if lk in keymap and isinstance(v,str):
                if keymap[lk]=="printer" and not result["printer"]: result["printer"]=clean(v)
                if keymap[lk]=="process" and not result["process"]: result["process"]=clean(v)
            if "filament" in lk:
                if isinstance(v,str): add_fil(v)
                elif isinstance(v,list):
                    for q in v: add_fil(q)
            if isinstance(v,dict): harvest_mapping(v, source)
            elif isinstance(v,list):
                for q in v:
                    if isinstance(q,dict): harvest_mapping(q, source)

    configs=_orca_config_candidates(data_dir)
    texts=[]
    for cfg in configs:
        try: text=cfg.read_text(encoding="utf-8-sig", errors="replace")
        except Exception: continue
        texts.append((cfg,text))
        parsed=False
        try:
            obj=json.loads(text); harvest_mapping(obj,str(cfg)); parsed=True
        except Exception: pass
        if not parsed:
            # OrcaSlicer.conf is often INI-like; parse permissively line-by-line so
            # duplicate sections/keys do not defeat ConfigParser.
            import re
            patterns={
                "printer": r'(?im)^\s*(?:printer|printer_preset|printer_settings_id|machine)\s*=\s*(.+?)\s*$',
                "process": r'(?im)^\s*(?:print|process|print_preset|print_settings_id)\s*=\s*(.+?)\s*$',
            }
            for key,pat in patterns.items():
                m=re.search(pat,text)
                if m and not result[key]: result[key]=clean(m.group(1))
            for m in re.finditer(r'(?im)^\s*filament(?:_\d+)?\s*=\s*(.+?)\s*$', text): add_fil(m.group(1))
        if (result["printer"] or result["process"]) and not result["source"]:
            result["source"]=str(cfg)
            result["layout"]=result["layout"] or ("structured" if parsed else "ini/raw")

    # Fallback: match exact installed preset names anywhere in Orca state files.
    # Prefer longer names to avoid matching generic words like "Default".
    combined="\n".join(t for _,t in texts)
    combined_low=combined.lower()
    def find_named(kind):
        hits=[]
        for ent in index[kind]:
            name=ent["name"]
            if len(name)<4: continue
            pos=combined_low.rfind(name.lower())
            if pos>=0:
                # Score context around occurrence: keys close to the value are strongest.
                ctx=combined_low[max(0,pos-120):pos+len(name)+60]
                score=len(name)
                if kind=="printer" and any(k in ctx for k in ["printer","machine"]): score+=100
                if kind=="process" and any(k in ctx for k in ["process","print"]): score+=100
                if kind=="filament" and "filament" in ctx: score+=100
                hits.append((score,pos,name))
        return max(hits, default=None)
    if not result["printer"]:
        h=find_named("printer")
        if h: result["printer"]=h[2]; result["discovery"].append("printer matched from Orca state text")
    if not result["process"]:
        h=find_named("process")
        if h: result["process"]=h[2]; result["discovery"].append("process matched from Orca state text")
    if not result["filaments"]:
        h=find_named("filament")
        if h: result["filaments"]=[h[2]]; result["discovery"].append("filament matched from Orca state text")
    if not result["source"] and configs:
        result["source"]="auto-scan: "+str(configs[0])
        result["layout"]="auto-discovered"
    return result


def _orca_find_profile(data_dir: Path, preset_name: Optional[str], kind: str, exe: Optional[str] = None) -> Optional[Path]:
    if not preset_name: return None
    target=preset_name.strip().replace(" (modified)", "")
    if not target or target.lower() in {"default","default setting","-- default --","default printer"}: return None
    index=_orca_build_profile_index(data_dir, exe)
    # Exact display-name match first; then filename stem; then normalized prefix.
    for ent in index.get(kind,[]):
        if ent["name"]==target or ent["path"].stem==target: return ent["path"]
    tl=target.lower()
    candidates=[ent for ent in index.get(kind,[]) if ent["name"].lower()==tl or ent["path"].stem.lower()==tl]
    return candidates[0]["path"] if candidates else None


def _orca_find_compatible_process(data_dir: Path, printer_name: str, exe: Optional[str] = None) -> Optional[Path]:
    candidates=[]
    index=_orca_build_profile_index(data_dir, exe)
    for ent in index["process"]:
        f=ent["path"]; obj=ent["obj"]; name=ent["name"]
        compat=obj.get("compatible_printers")
        ok=False
        if isinstance(compat,list): ok=printer_name in [str(x) for x in compat]
        elif isinstance(compat,str): ok=printer_name==compat
        # Inheritance may carry compatibility; vendor/name match is a usable fallback.
        if not ok:
            pwords=[w for w in printer_name.lower().replace('-',' ').split() if len(w)>=3]
            ok=sum(1 for w in pwords if w in name.lower())>=2
        if not ok: continue
        low=name.lower(); score=0
        if "0.20" in low or "0.2" in low: score+=20
        if "standard" in low or "normal" in low or "default" in low: score+=12
        if "draft" in low or "fine" in low: score-=3
        if "user" in {x.lower() for x in f.parts}: score+=3
        candidates.append((score,f))
    if candidates:
        candidates.sort(key=lambda x:(x[0],str(x[1])),reverse=True)
        return candidates[0][1]
    # Last-resort: a generic process is still preferable to making the user find files.
    generic=[]
    for ent in index["process"]:
        low=ent["name"].lower(); score=0
        if "0.20" in low or "0.2" in low: score+=10
        if "standard" in low or "normal" in low or "default" in low: score+=8
        if score: generic.append((score,ent["path"]))
    if generic:
        generic.sort(key=lambda x:(x[0],str(x[1])),reverse=True)
        return generic[0][1]
    return None


def _orca_infer_machine_without_config(data_dir: Path, exe: str) -> Optional[Path]:
    """Final automatic fallback when Orca's active-state serialization is unavailable.

    Prefer a recently modified user machine profile.  If none exists and only one
    bundled machine family can be identified from state text, use that.  This is
    intentionally automatic; AlphaSlice never asks the user to browse profile files.
    """
    idx=_orca_build_profile_index(data_dir, exe)["printer"]
    user=[]
    for ent in idx:
        if "user" in {x.lower() for x in ent["path"].parts}:
            try: mt=ent["path"].stat().st_mtime
            except Exception: mt=0
            user.append((mt,ent["path"]))
    if user:
        user.sort(reverse=True); return user[0][1]
    return None


def _orca_prepare_profiles(exe: str, option: Dict[str, Any], stem: str) -> Dict[str, Any]:
    data_dir=_orca_data_dir(exe)
    selections=_orca_read_current_selections(data_dir, exe)
    machine=_orca_find_profile(data_dir,selections.get("printer"),"printer",exe)
    if not machine:
        machine=_orca_infer_machine_without_config(data_dir,exe)
        if machine:
            try:
                obj=json.loads(machine.read_text(encoding="utf-8-sig",errors="replace"))
                selections["printer"]=str(obj.get("name") or machine.stem)
                selections["discovery"].append("printer inferred from most recent Orca user machine profile")
            except Exception: pass
    process=_orca_find_profile(data_dir,selections.get("process"),"process",exe)
    process_fallback=False
    if machine and not process and selections.get("printer"):
        process=_orca_find_compatible_process(data_dir,selections["printer"],exe); process_fallback=bool(process)
        if process and not selections.get("process"):
            try:
                pobj=json.loads(process.read_text(encoding="utf-8-sig",errors="replace"))
                selections["process"]=str(pobj.get("name") or process.stem)
                selections["discovery"].append("process automatically chosen from compatible Orca presets")
            except Exception: pass
    filaments=[]
    for name in selections.get("filaments") or []:
        f=_orca_find_profile(data_dir,name,"filament",exe)
        if f and f not in filaments: filaments.append(f)

    missing=[]
    if not machine: missing.append("printer profile")
    if not process: missing.append("process profile")
    if missing:
        roots=[str(x) for x in _orca_profile_roots(data_dir,exe)]
        raise RuntimeError(
            "AlphaSlice automatically searched Orca's configuration, user/cloud presets, and bundled system profiles but could not resolve "
            + " and ".join(missing)
            + f". data_dir={data_dir}; config={selections.get('source') or 'none'}; searched_roots={roots}. "
              "No manual AppData setup is required; this diagnostic identifies what AlphaSlice still needs to support."
        )

    try: proc=json.loads(process.read_text(encoding="utf-8-sig",errors="replace"))
    except Exception as exc: raise RuntimeError(f"Could not read Orca process profile {process}: {exc}") from exc
    proc["name"]=f"AlphaSlice {option['label']}"
    proc["wall_loops"]=str(option["wall_loops"])
    proc["sparse_infill_density"]=f"{option['infill_density_pct']}%"
    proc["sparse_infill_pattern"]=option["infill_pattern"]
    proc["top_shell_layers"]=str(option["top_shell_layers"])
    proc["bottom_shell_layers"]=str(option["bottom_shell_layers"])
    proc["enable_support"]="1"; proc["support_type"]="tree(auto)"; proc["support_style"]="organic"
    proc["print_settings_id"]=f"AlphaSlice {option['label']}"
    override=EXPORT_DIR/f"{stem}_process_from_orca.json"
    override.write_text(json.dumps(proc,indent=2),encoding="utf-8")
    return {"data_dir":data_dir,"selections":selections,"machine":machine,"base_process":process,"process_override":override,"filaments":filaments,"process_fallback":process_fallback}

def _orca_process_profile(option: Dict[str,Any]) -> Dict[str,Any]:
    """Machine-independent Orca/Bambu process overrides chosen by AlphaSlice."""
    support_type = "tree(auto)"
    support_style = "organic"
    return {
        "wall_loops": str(option["wall_loops"]),
        "sparse_infill_density": f"{option['infill_density_pct']}%",
        "sparse_infill_pattern": option["infill_pattern"],
        "top_shell_layers": str(option["top_shell_layers"]),
        "bottom_shell_layers": str(option["bottom_shell_layers"]),
        "detect_overhang_wall": "1",
        "enable_support": "1",
        "support_type": support_type,
        "support_style": support_style,
    }


def _orca_process_profile(option: Dict[str,Any]) -> Dict[str,Any]:
    """Minimal Orca process preset used only as a CLI override.

    OrcaSlicer itself will consume this JSON and write the final 3MF.  AlphaSlice
    no longer edits Orca's private 3MF metadata structure directly.
    """
    return {
        "type": "process",
        "name": f"AlphaSlice {option['label']} ({option['strength_class']})",
        "from": "user",
        "instantiation": "true",
        "inherits": "",
        "wall_loops": str(option["wall_loops"]),
        "sparse_infill_density": f"{option['infill_density_pct']}%",
        "sparse_infill_pattern": option["infill_pattern"],
        "top_shell_layers": str(option["top_shell_layers"]),
        "bottom_shell_layers": str(option["bottom_shell_layers"]),
        "detect_overhang_wall": "1",
        "enable_support": "1",
        "support_type": "tree(auto)",
        "support_style": "organic",
        "print_settings_id": f"AlphaSlice {option['label']}",
    }


def _verify_orca_native_3mf(path: Path, expected: Dict[str,Any]) -> Dict[str,Any]:
    """Inspect the file Orca wrote.  Do not modify it."""
    result = {"exists": path.exists(), "orca_authored": False, "settings_found": {}, "verified": False}
    if not path.exists() or path.stat().st_size < 100:
        return result
    try:
        with zipfile.ZipFile(path, "r") as z:
            names = set(z.namelist())
            result["orca_authored"] = "Metadata/project_settings.config" in names
            if "Metadata/project_settings.config" in names:
                project = json.loads(z.read("Metadata/project_settings.config").decode("utf-8-sig"))
                for k in expected:
                    if k in project:
                        result["settings_found"][k] = str(project.get(k))
                # Orca may normalize certain textual values, so verify the core
                # structural settings exactly and report support values separately.
                core = ["wall_loops", "sparse_infill_density", "sparse_infill_pattern", "top_shell_layers", "bottom_shell_layers"]
                result["verified"] = all(str(project.get(k)) == str(expected[k]) for k in core)
    except Exception as exc:
        result["verification_error"] = f"{type(exc).__name__}: {exc}"
    return result


def _run_orca_native_export(exe: str, mesh: trimesh.Trimesh, option: Dict[str,Any], session_id: str) -> tuple[Path, Dict[str,Any], str]:
    """Ask OrcaSlicer itself to author the project 3MF using Orca's active
    machine/process context plus AlphaSlice's process overrides.

    A process JSON by itself is insufficient for Orca's CLI and can terminate
    with the Microsoft C++ exception 0xE06D7363 on Windows.
    """
    EXPORT_DIR.mkdir(parents=True, exist_ok=True)
    stem = f"AlphaSlice_{option['key']}_{session_id}"
    stl_path = EXPORT_DIR / f"{stem}.stl"
    out_path = EXPORT_DIR / f"{stem}.3mf"
    log_path = EXPORT_DIR / f"{stem}_orca_cli.log"

    for f in (out_path, log_path):
        try:
            if f.exists(): f.unlink()
        except Exception:
            pass

    mesh_to_write = mesh.copy()
    _translate_to_bed(mesh_to_write)
    mesh_to_write.export(stl_path)
    profiles=_orca_prepare_profiles(exe, option, stem)

    settings_arg = f"{profiles['machine']};{profiles['process_override']}"
    cmd = [exe, "--datadir", str(profiles['data_dir']),
           "--load-settings", settings_arg]
    if profiles["filaments"]:
        # One filament is enough for a normal single-nozzle project. For multi-nozzle
        # machines keep all selections Orca saved, separated the way its CLI expects.
        cmd += ["--load-filaments", ";".join(str(x) for x in profiles["filaments"])]
    else:
        cmd += ["--load-defaultfila", "1"]
    cmd += ["--arrange", "1", "--ensure-on-bed",
            "--export-3mf", str(out_path), str(stl_path)]

    try:
        completed = subprocess.run(
            cmd, cwd=str(Path(exe).parent), capture_output=True, text=True,
            timeout=120, creationflags=(subprocess.CREATE_NO_WINDOW if os.name == "nt" and hasattr(subprocess, "CREATE_NO_WINDOW") else 0),
        )
        cli_text=(completed.stdout or "") + ("\n" + completed.stderr if completed.stderr else "")
        diagnostic={
            "command": cmd,
            "selections": profiles["selections"],
            "machine_profile": str(profiles["machine"]),
            "base_process_profile": str(profiles["base_process"]),
            "process_override": str(profiles["process_override"]),
            "filament_profiles": [str(x) for x in profiles["filaments"]],
            "return_code": completed.returncode,
        }
        log_path.write_text(json.dumps(diagnostic, indent=2)+"\n\nOUTPUT:\n"+cli_text, encoding="utf-8", errors="replace")
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError("OrcaSlicer CLI did not finish creating the native project within 120 seconds.") from exc
    except Exception as exc:
        raise RuntimeError(f"Could not run OrcaSlicer's native 3MF exporter: {type(exc).__name__}: {exc}") from exc

    if completed.returncode != 0:
        unsigned=completed.returncode & 0xffffffff
        code_note=f"exit code {completed.returncode} (0x{unsigned:08X})"
        if unsigned == 0xE06D7363:
            code_note += " — Microsoft C++ exception; Orca normally throws this when the CLI profile context is incomplete/incompatible"
        tail=cli_text.strip()[-1800:] or code_note
        raise RuntimeError(f"OrcaSlicer CLI rejected the project export: {code_note}. Orca selections used: printer={profiles['selections'].get('printer')!r}, process={profiles['selections'].get('process')!r}. Details: {tail}. Diagnostic log: {log_path}")
    if not out_path.exists() or out_path.stat().st_size < 100:
        tail=cli_text.strip()[-1800:] or "Orca returned success but no output file was produced."
        raise RuntimeError(f"OrcaSlicer did not create the native 3MF. Details: {tail}. Diagnostic log: {log_path}")

    expected=_orca_process_profile(option)
    verification=_verify_orca_native_3mf(out_path, expected)
    verification.update({
        "process_json": str(profiles["process_override"]), "cli_log": str(log_path),
        "native_writer": "OrcaSlicer CLI", "active_printer": profiles["selections"].get("printer"),
        "active_process": profiles["selections"].get("process")
    })
    return out_path, verification, cli_text


@app.post("/api/orca/open")
def orca_open(req: OrcaOpenRequest) -> JSONResponse:
    try:
        s = SESSIONS.get(req.session_id)
        if not s:
            raise HTTPException(status_code=404, detail="Session expired. Re-import the model.")
        exe = (req.executable or "").strip() or _find_orcaslicer()
        if not exe or not Path(exe).exists():
            raise HTTPException(status_code=400, detail="OrcaSlicer was not found. Install OrcaSlicer or paste its executable path below.")
        if not req.analysis_session_id:
            raise HTTPException(status_code=400, detail="Run Analyze & Optimize first so AlphaSlice can create an Orca-native project.")
        a = SESSIONS.get(req.analysis_session_id)
        if not a or a.get("kind") != "analysis":
            raise HTTPException(status_code=404, detail="Analysis session expired. Run Analyze & Optimize again.")
        opt = next((x for x in a.get("options", []) if x.get("key") == req.option.lower()), None)
        if not opt:
            raise HTTPException(status_code=400, detail="Unknown AlphaSlice option.")

        try:
            out, verification, _ = _run_orca_native_export(exe, s["mesh"].copy(), opt, req.session_id)
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"Could not create an Orca-native project: {exc}")

        try:
            subprocess.Popen([exe, str(out)], cwd=str(Path(exe).parent))
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"Orca created the project at {out}, but AlphaSlice could not reopen it in Orca: {type(exc).__name__}: {exc}")

        return JSONResponse({
            "ok": True,
            "path": str(out),
            "applied": opt,
            "project_3mf": True,
            "verification": verification,
            "message": "OrcaSlicer itself authored this 3MF using AlphaSlice's process override; AlphaSlice did not patch Orca metadata directly.",
        })
    except HTTPException:
        raise
    except Exception as exc:
        print("AlphaSlice /api/orca/open unexpected error:", traceback.format_exc(), file=sys.stderr)
        raise HTTPException(status_code=500, detail=f"Unexpected AlphaSlice server error: {type(exc).__name__}: {exc}")


@app.post("/api/supports")
def generate_supports(req: SupportRequest) -> JSONResponse:
    s=SESSIONS.get(req.session_id)
    if not s or s.get("kind")!="preview":
        raise HTTPException(status_code=404,detail="Preview session expired. Re-import the model.")
    angle=float(np.clip(req.overhang_angle_deg,35.0,65.0))
    result=_adaptive_supports(s["mesh"],angle)
    s["adaptive_supports"]=result
    return JSONResponse(result)


@app.post("/api/supports/export")
def export_supports(req: SupportExportRequest) -> Response:
    s=SESSIONS.get(req.session_id)
    if not s or s.get("kind")!="preview":
        raise HTTPException(status_code=404,detail="Preview session expired. Re-import the model.")
    result=s.get("adaptive_supports") or _adaptive_supports(s["mesh"],48.0)
    sm=result.get("support_mesh",{})
    if not sm.get("faces"):
        raise HTTPException(status_code=400,detail="No adaptive supports were generated for this orientation.")
    verts=np.asarray(sm["vertices"],dtype=float).reshape(-1,3); faces=np.asarray(sm["faces"],dtype=int).reshape(-1,3)
    mesh=trimesh.Trimesh(vertices=verts,faces=faces,process=False)
    payload=trimesh.exchange.stl.export_stl(mesh)
    base=Path(s.get("filename") or "model").stem
    return Response(content=payload,media_type="model/stl",headers={"Content-Disposition":f'attachment; filename="{base}_AlphaSlice_AdaptiveSupports.stl"'})


@app.post("/api/analyze")
async def analyze(preview_session_id: str=Form(""), prompt: str=Form(""), groq_api_key: str=Form(""), file: Optional[UploadFile]=File(None)) -> JSONResponse:
    if preview_session_id and preview_session_id in SESSIONS and SESSIONS[preview_session_id].get("kind")=="preview":
        p=SESSIONS[preview_session_id]; mesh=p["mesh"].copy(); filename=p["filename"]; orientation_label=p["orientation_label"]
    elif file is not None:
        raw=await file.read(); mesh=_load_mesh(file.filename or "model.stl",raw); _translate_to_bed(mesh); filename=file.filename or "model.stl"; orientation_label="Imported orientation"
    else:
        raise HTTPException(status_code=400,detail="Import a model first.")

    intent=_parse_intent_groq(prompt,groq_api_key) or _parse_intent_local(prompt)
    if groq_api_key.strip() and intent.get("source")!="Groq + local validation": intent["assumptions"].append("Groq was unavailable; AlphaSlice fell back to the local intent parser.")
    orientations=_orientation_candidates(mesh); faces=_face_analysis(mesh,intent); options=_build_options(mesh,orientations,intent)
    sid=_new_id(); SESSIONS[sid]={"kind":"analysis","mesh":mesh,"filename":filename,"intent":intent,"orientations":orientations,"options":options,"orientation_label":orientation_label}
    return JSONResponse({"session_id":sid,"filename":filename,"orientation_label":orientation_label,"intent":intent,"geometry":_geometry_summary(mesh),"orientation_candidates":orientations,"analysis":faces,"options":options,"viewer_mesh":_mesh_to_json(mesh),"status":{"geometry":"complete","intent":intent["source"],"fea":"structural proxy active; real FEA is next milestone","support":"selected-bed orientation + overhang analysis active","export":"slicer-ready 3MF with per-object AlphaSlice overrides active"}})


PRINTER_TARGETS = {
    "creality_k2_plus": {
        "name": "Creality K2 Plus",
        "slug": "Creality_K2_Plus",
        "bed_x": 350.0,
        "bed_y": 350.0,
        "build_z": 350.0,
        "nozzle": 0.4,
    },
    "bambu_p1s": {
        "name": "Bambu Lab P1S",
        "slug": "Bambu_P1S",
        "bed_x": 256.0,
        "bed_y": 256.0,
        "build_z": 256.0,
        "nozzle": 0.4,
    },
}


def _model_settings_xml(object_id: str, object_name: str, option: Dict[str, Any], printer: Dict[str, Any]) -> str:
    """Build Orca/Bambu-style sparse per-object overrides.

    Model-only 3MF projects are intentionally used here: the slicer keeps its
    own filament/profile defaults while the model carries AlphaSlice's structural
    process overrides. This avoids coupling the file to a user's local preset IDs.
    """
    import xml.etree.ElementTree as ET
    config = ET.Element("config")
    obj = ET.SubElement(config, "object", {"id": str(object_id)})
    def meta(k: str, v: Any):
        ET.SubElement(obj, "metadata", {"key": str(k), "value": str(v)})
    meta("name", object_name)
    meta("wall_loops", option["wall_loops"])
    meta("sparse_infill_density", f'{option["infill_density_pct"]}%')
    meta("sparse_infill_pattern", option["infill_pattern"])
    meta("top_shell_layers", option["top_shell_layers"])
    meta("bottom_shell_layers", option["bottom_shell_layers"])
    meta("enable_support", "1")
    meta("support_type", "tree(auto)")
    meta("support_style", "organic")
    # AlphaSlice metadata is namespaced as plain metadata; Orca preserves unknown
    # model metadata while known print-setting keys above are applied as overrides.
    meta("ecoslice_target_printer", printer["name"])
    meta("ecoslice_nozzle_mm", printer["nozzle"])
    meta("ecoslice_optimization", option["key"])
    meta("ecoslice_strength_class", option.get("strength_class", "FUNCTIONAL"))
    try:
        ET.indent(config, space=" ")
    except Exception:
        pass
    return '<?xml version="1.0" encoding="UTF-8"?>\n' + ET.tostring(config, encoding="unicode") + "\n"


def _build_slicer_ready_3mf(mesh: trimesh.Trimesh, option: Dict[str, Any], printer_key: str, object_name: str) -> bytes:
    import io, zipfile, xml.etree.ElementTree as ET
    printer = PRINTER_TARGETS.get(printer_key)
    if not printer:
        raise ValueError("Unknown printer target")
    ext = np.asarray(mesh.extents, dtype=float)
    if ext[0] > printer["bed_x"] + 1e-6 or ext[1] > printer["bed_y"] + 1e-6 or ext[2] > printer["build_z"] + 1e-6:
        raise ValueError(f'Model {ext[0]:.1f} × {ext[1]:.1f} × {ext[2]:.1f} mm exceeds the {printer["name"]} build volume.')

    repaired_mesh, repair_info = _repair_mesh_for_export(mesh, float(printer.get("nozzle", 0.4)))
    base = trimesh.exchange.threemf.export_3MF(repaired_mesh)
    src = zipfile.ZipFile(io.BytesIO(base), "r")
    model_xml = src.read("3D/3dmodel.model")
    root = ET.fromstring(model_xml)
    ns = {"m": "http://schemas.microsoft.com/3dmanufacturing/core/2015/02"}
    first_obj = root.find(".//m:object", ns)
    object_id = first_obj.attrib.get("id", "1") if first_obj is not None else "1"
    settings_xml = _model_settings_xml(object_id, object_name, option, printer)

    out = io.BytesIO()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as dst:
        for info in src.infolist():
            dst.writestr(info, src.read(info.filename))
        dst.writestr("Metadata/model_settings.config", settings_xml.encode("utf-8"))
        dst.writestr("Metadata/AlphaSlice.json", json.dumps({
            "version": "1.10.0",
            "target_printer": printer,
            "optimization": option,
            "format": "model-only slicer project with per-object process overrides",
            "mesh_repair": repair_info,
        }, indent=2).encode("utf-8"))
    src.close()
    payload = out.getvalue()
    # Verify the settings survived packaging before returning a download.
    with zipfile.ZipFile(io.BytesIO(payload), "r") as check:
        if "Metadata/model_settings.config" not in check.namelist():
            raise RuntimeError("3MF verification failed: model settings are missing")
        txt = check.read("Metadata/model_settings.config").decode("utf-8")
        required = [
            f'value="{option["wall_loops"]}"',
            f'value="{option["infill_density_pct"]}%"',
            'key="sparse_infill_pattern"',
        ]
        if not all(x in txt for x in required):
            raise RuntimeError("3MF verification failed: optimization settings were not embedded")
    return payload


@app.post("/api/export")
def export(req: ExportRequest) -> Response:
    s=SESSIONS.get(req.session_id)
    if not s or s.get("kind")!="analysis": raise HTTPException(status_code=404,detail="Analysis session expired. Re-run Analyze & Optimize.")
    if req.option.lower() not in {"eco","balanced","strength"}: raise HTTPException(status_code=400,detail="Unknown optimization option.")
    printer=PRINTER_TARGETS.get(req.printer)
    if not printer: raise HTTPException(status_code=400,detail="Choose a supported printer.")
    opt=next((x for x in s.get("options",[]) if x.get("key")==req.option.lower()),None)
    if opt is None: raise HTTPException(status_code=500,detail="Optimization data is missing. Re-run Analyze & Optimize.")
    mesh=s["mesh"].copy(); _translate_to_bed(mesh)
    base=Path(s["filename"] or "model").stem
    try:
        payload=_build_slicer_ready_3mf(mesh,opt,req.printer,base)
    except Exception as exc:
        raise HTTPException(status_code=500,detail=f"Optimized 3MF export failed: {exc}")
    name=f"{base}_AlphaSlice_{req.option.lower()}_{printer['slug']}.3mf"
    return Response(content=payload,media_type="model/3mf",headers={"Content-Disposition":f'attachment; filename="{name}"'})


# ===== Vision OPS integrated endpoints v1.19 — Groq-only primary/backup vision =====
def _visionops_groq(image_data_url: str, api_key: str, context: str = "") -> Dict[str, Any]:
    if not api_key.strip():
        return {
            "status": "Monitoring",
            "failure_type": "Groq API key required",
            "severity": "info",
            "confidence": 0.0,
            "probable_cause": "No Groq API key supplied.",
            "explanation": "Camera monitoring is active, but AI frame classification requires the Groq key saved in AlphaSlice.",
            "recommended_action": "Save your Groq API key, then analyze the frame again.",
            "source": "local fallback",
            "model": None,
        }
    instruction = (
        "You are Vision OPS, a visual failure detector for FDM 3D printing. Analyze ONE camera frame. "
        "Inspect the entire BUILD PLATE first, especially the lower/foreground area, not only the nozzle. A failure may be obvious away from the nozzle. "
        "SPAGHETTI IS HIGH-PRIORITY: identify loose, thin, unsupported filament strands, random loops/curls, chaotic crossings, bird-nest tangles, filament suspended in air, or piles of stringy extrusion that do not form a coherent designed surface. "
        "Do NOT dismiss chaotic loose strands as a lattice or intended geometry just because some lines cross. An intentional lattice should look regular, repeated, connected, geometrically organized, and anchored to the part. Random wandering strands and loops are spaghetti. "
        "If obvious spaghetti occupies a meaningful area of the plate, classify Needs Attention with failure_type 'Spaghetti / failed extrusion', severity high, and confidence typically >= 0.85. "
        "IMPORTANT ADHESION CALIBRATION: a nozzle normally travels slightly above printed plastic, and the printed part is normally separate from the nozzle. "
        "A small flat colored shape directly beneath or near the nozzle can simply be the model currently being printed. This alone is NOT adhesion loss. "
        "Only call adhesion loss/detachment when the frame visibly shows bed-separation evidence such as a clearly lifted or curled edge, a visible gap/shadow under the part, "
        "the entire part displaced or rotated from its expected position, the nozzle visibly dragging a loose part, or spaghetti/loose filament showing the print is no longer attached. "
        "If the object looks flat and stationary on the build plate, assume it remains attached unless separation is actually visible. "
        "Also check for major layer shift, nozzle drag, filament blob, smoke/heat cues, or another clearly visible abnormality. "
        "Do not infer a fault merely because the current layer is small, oddly shaped, purple, partially occluded, or because the nozzle is not touching the visible object. "
        "Use confidence above 0.75 when visual evidence is direct and obvious. For genuinely ambiguous evidence, return Printing or Monitoring with confidence <= 0.45. "
        "Return JSON only with keys: status (Printing, Idle, Monitoring, or Needs Attention), failure_type, severity (none, low, medium, high, critical), confidence (0 to 1), probable_cause, explanation, recommended_action. "
        "If no clear fault is visible, use failure_type 'No visible anomaly', severity 'none', and recommended_action 'Continue monitoring'."
    )
    if context.strip():
        instruction += " Job context: " + context.strip()

    errors = []
    retry_after_header = 0.0
    models = ("qwen/qwen3.8-27b",)
    for model in models:
        try:
            data = _groq_generate_json(instruction, api_key, image_data_url=image_data_url, model=model)
            # Conservative post-calibration for the most common false positive: mistaking normal
            # nozzle/part separation for bed adhesion loss. The model must describe actual bed-separation evidence.
            raw_failure = str(data.get("failure_type") or "No visible anomaly")
            raw_explanation = str(data.get("explanation") or "No explanation returned.")
            failure_l = raw_failure.lower()
            explanation_l = raw_explanation.lower()
            adhesion_like = any(x in failure_l for x in ("adhesion", "detach", "lifted part", "bed separation"))
            hard_evidence = any(x in explanation_l for x in (
                "lifted edge", "curled edge", "curled corner", "gap under", "gap between", "shadow under",
                "peeled", "off the bed", "moved on the bed", "shifted on the bed", "rotated on the bed",
                "dragging the part", "dragged by the nozzle", "loose part", "detached from the bed", "spaghetti"
            ))
            if adhesion_like and not hard_evidence:
                data = dict(data)
                data["status"] = "Printing"
                data["failure_type"] = "No clear adhesion failure"
                data["severity"] = "none"
                data["confidence"] = min(0.45, float(data.get("confidence") or 0.0))
                data["probable_cause"] = "No direct bed-separation evidence is visible in this frame."
                data["explanation"] = "The frame does not show a lifted edge, bed gap, displacement, nozzle-dragged part, or other direct evidence of adhesion loss. The visible material may be normal in-progress extrusion. Continue monitoring for repeat evidence."
                data["recommended_action"] = "Continue monitoring; do not pause the print based on this frame alone."
            return {
                "status": str(data.get("status") or "Monitoring"),
                "failure_type": str(data.get("failure_type") or "No visible anomaly"),
                "severity": str(data.get("severity") or "none"),
                "confidence": max(0.0, min(1.0, float(data.get("confidence") or 0))),
                "probable_cause": str(data.get("probable_cause") or "Not determined"),
                "explanation": str(data.get("explanation") or "No explanation returned."),
                "recommended_action": str(data.get("recommended_action") or "Continue monitoring"),
                "source": "Groq vision",
                "model": model,
            }
        except urllib.error.HTTPError as exc:
            try:
                raw = exc.read().decode("utf-8", "replace")
                parsed = json.loads(raw)
                detail = parsed.get("error", {}).get("message") or raw
            except Exception:
                detail = str(exc)
            try:
                retry_after_header = max(retry_after_header, float((exc.headers or {}).get("retry-after") or 0))
            except Exception:
                pass
            errors.append(f"{model}: HTTP {exc.code}: {detail}")
            # IMPORTANT: a 429 is quota-wide for the model/org. Do not immediately hit the backup
            # model or another API key; that creates a second request while the account is throttled.
            if exc.code in (401, 429):
                break
            # A 403 can be model-specific (org/project model permission), so the backup model may help.
        except Exception as exc:
            errors.append(f"{model}: {type(exc).__name__}: {exc}")

    detail = " | ".join(errors) if errors else "Unknown Groq error"
    rate_limited = any("HTTP 429" in e for e in errors)
    retry_after = max(20.0, retry_after_header)
    if rate_limited and retry_after_header <= 0:
        m = re.search(r"retry(?:\s+after|\s+in)?[^0-9]{0,12}([0-9.]+)s?", detail, re.IGNORECASE)
        if m:
            try:
                retry_after = max(5.0, float(m.group(1)))
            except Exception:
                pass
    invalid_key = any("HTTP 401" in e for e in errors)
    # Do not call every 403 a model-permission block. Groq uses 403 for multiple permission restrictions.
    explicit_permission_block = any("model_permission_blocked_org" in e or "model_permission_blocked_project" in e for e in errors)
    daily_limit = rate_limited and ("tokens per day" in detail.lower() or "TPD" in detail)
    failure_type = "Groq daily token budget reached" if daily_limit else ("Groq cooldown" if rate_limited else ("Groq model access blocked" if explicit_permission_block else ("Invalid Groq API key" if invalid_key else "Groq vision unavailable")))
    action = (
        "Vision OPS will keep the local sentinel active and retry AI after Groq's reset window." if daily_limit else
        "Vision OPS will retry automatically after the cooldown." if rate_limited else
        "Check Groq Organization/Project model permissions." if explicit_permission_block else
        "Replace the saved key with a valid Groq API key." if invalid_key else
        "Use Verify models to view Groq's exact error code and message."
    )
    return {
        "status": "Monitoring",
        "failure_type": failure_type,
        "severity": "info",
        "confidence": 0.0,
        "probable_cause": "Groq daily token allowance is exhausted for this organization/model." if daily_limit else ("Groq request quota is temporarily limited." if rate_limited else "Vision OPS could not complete the Groq request."),
        "explanation": detail,
        "recommended_action": action,
        "source": "Groq rate limit" if rate_limited else "Groq error",
        "model": None,
        "rate_limited": rate_limited,
        "retry_after_seconds": retry_after if rate_limited else 0,
    }


def _groq_http_error_info(exc: urllib.error.HTTPError) -> Dict[str, Any]:
    try:
        raw = exc.read().decode("utf-8", "replace")
    except Exception:
        raw = ""
    parsed: Dict[str, Any] = {}
    if raw:
        try:
            parsed = json.loads(raw)
        except Exception:
            parsed = {}
    err = parsed.get("error") if isinstance(parsed, dict) else None
    if not isinstance(err, dict):
        err = {}
    message = err.get("message") or raw or str(exc)
    cf_1010 = "1010" in str(message) or "banned the browser signature" in str(message).lower()
    if cf_1010:
        message = "Cloudflare blocked the HTTP client signature (error 1010). AlphaSlice sends a custom User-Agent to avoid this block."
    return {
        "http_status": int(getattr(exc, "code", 0) or 0),
        "type": err.get("type"),
        "code": err.get("code") or ("cloudflare_1010" if cf_1010 else None),
        "message": message,
    }


def _groq_list_models(api_key: str) -> Dict[str, Any]:
    req = urllib.request.Request(
        "https://api.groq.com/openai/v1/models",
        headers=_groq_headers(api_key),
        method="GET",
    )
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            payload = json.loads(r.read().decode("utf-8"))
        ids = [str(x.get("id")) for x in (payload.get("data") or []) if isinstance(x, dict) and x.get("id")]
        return {"ok": True, "http_status": 200, "models": ids}
    except urllib.error.HTTPError as exc:
        return {"ok": False, **_groq_http_error_info(exc), "models": []}
    except Exception as exc:
        return {"ok": False, "message": f"{type(exc).__name__}: {exc}", "models": []}


def _groq_access_check(api_key: str) -> Dict[str, Any]:
    if not api_key.strip():
        return {"ok": False, "message": "Enter a Groq API key first.", "models": {}, "account": {}}

    account = _groq_list_models(api_key)
    target_models = ("qwen/qwen3.8-27b",)
    probe = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Y9Z8f8AAAAASUVORK5CYII="
    prompt = 'Return JSON only: {"ok": true}. This is a tiny multimodal connectivity test.'
    out: Dict[str, Any] = {}
    for model in target_models:
        try:
            data = _groq_generate_json(prompt, api_key, image_data_url=probe, model=model, max_completion_tokens=80)
            out[model] = {"ok": bool(data.get("ok", True)), "http_status": 200, "error": None}
        except urllib.error.HTTPError as exc:
            info = _groq_http_error_info(exc)
            out[model] = {"ok": False, "error": info.get("message"), **info}
        except Exception as exc:
            out[model] = {"ok": False, "error": f"{type(exc).__name__}: {exc}", "message": f"{type(exc).__name__}: {exc}"}

    ok = any(v.get("ok") for v in out.values())
    both = all(v.get("ok") for v in out.values())
    permission_codes = {"model_permission_blocked_org", "model_permission_blocked_project"}
    exact_permission_block = any(v.get("code") in permission_codes for v in out.values()) or account.get("code") in permission_codes

    if both:
        message = "Groq verified: primary and backup vision models are both accessible."
    elif ok:
        available = [k for k,v in out.items() if v.get("ok")]
        failed = [k for k,v in out.items() if not v.get("ok")]
        message = f"Groq partially verified: {', '.join(available)} works; {', '.join(failed)} failed."
    elif exact_permission_block:
        message = "Groq returned an explicit model_permission_blocked error. Check Organization and Project model permissions."
    elif account.get("ok"):
        listed = [m for m in target_models if m in set(account.get("models") or [])]
        if listed:
            message = "Groq key is valid and the Qwen models are listed for this account, but the multimodal request was rejected. See the exact API error below."
        else:
            message = "Groq key is valid, but the requested Qwen vision models are not present in this key's /models response."
    else:
        message = "Groq account/model check failed. See the exact API error below."

    return {
        "ok": ok,
        "both_models": both,
        "message": message,
        "account": account,
        "models": out,
    }


@app.post("/api/groq/check")
async def groq_check(req: GroqAccessCheckRequest) -> JSONResponse:
    return JSONResponse(_groq_access_check(req.api_key))


@app.post("/api/visionops/analyze")
async def visionops_analyze(req: VisionOpsAnalyzeRequest) -> JSONResponse:
    if not req.image_data_url.startswith("data:image/"):
        raise HTTPException(status_code=400, detail="Vision OPS expected a camera image.")
    if len(req.image_data_url) > 8_000_000:
        raise HTTPException(status_code=413, detail="Camera frame is too large.")
    return JSONResponse(_visionops_groq(req.image_data_url, req.api_key, req.context))


def _normalize_moonraker_base_url(value: str) -> str:
    raw = (value or "").strip()
    if not raw:
        raise HTTPException(status_code=400, detail="Enter your Fluidd / Moonraker address.")
    if "://" not in raw:
        raw = "http://" + raw
    parsed = urllib.parse.urlparse(raw)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise HTTPException(status_code=400, detail="Fluidd / Moonraker address must be an http:// or https:// URL.")
    # Fluidd is normally served from the same host as Moonraker.  Keep the origin
    # and discard browser hash/routes such as /#/dashboard.
    return f"{parsed.scheme}://{parsed.netloc}".rstrip("/")


def _moonraker_http(base_url: str, path: str, api_key: str = "", method: str = "GET", payload: Optional[Dict[str, Any]] = None, timeout: float = 6.0) -> Dict[str, Any]:
    base = _normalize_moonraker_base_url(base_url)
    url = base + path
    headers = {"Accept": "application/json", "User-Agent": "AlphaSlice/1.43 MoonrakerClient"}
    data = None
    if api_key.strip():
        headers["X-Api-Key"] = api_key.strip()
    if payload is not None:
        headers["Content-Type"] = "application/json"
        data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read().decode("utf-8", errors="replace")
            try:
                body = json.loads(raw) if raw else {}
            except Exception:
                body = {"raw": raw}
            return {"ok": True, "status": getattr(r, "status", 200), "body": body, "url": url}
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8", errors="replace")[:1200]
        try:
            parsed = json.loads(raw)
            detail = parsed.get("error", {}).get("message") or parsed.get("message") or raw
        except Exception:
            detail = raw or str(exc)
        raise HTTPException(status_code=502, detail=f"Moonraker rejected the request ({exc.code}): {detail}")
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Could not reach Fluidd / Moonraker: {type(exc).__name__}: {exc}")


def _moonraker_pause_state(base_url: str, api_key: str = "") -> Dict[str, Any]:
    """Read both pause_resume and print_stats so a pause is verified, not assumed."""
    try:
        q = _moonraker_http(
            base_url,
            "/printer/objects/query?pause_resume&print_stats",
            api_key,
            "GET",
            timeout=5.0,
        )
        body = q.get("body") or {}
        status = ((body.get("result") or {}).get("status") or {}) if isinstance(body, dict) else {}
        pr = status.get("pause_resume") or {}
        ps = status.get("print_stats") or {}
        return {
            "is_paused": bool(pr.get("is_paused")) or str(ps.get("state") or "").lower() == "paused",
            "pause_resume": pr,
            "print_state": ps.get("state"),
            "filename": ps.get("filename"),
        }
    except Exception as exc:
        return {"is_paused": False, "status_error": str(exc)}


def _moonraker_pause(req: FluiddActionRequest) -> Dict[str, Any]:
    """Pause robustly and verify the printer actually entered the paused state.

    Native Moonraker pause is the primary path.  Custom G-code is fallback only,
    because Klipper may return HTTP 200 even when a script contains an unknown
    command, which made older AlphaSlice builds falsely report PAUSE_PRINT success.
    """
    before = _moonraker_pause_state(req.base_url, req.api_key)
    if before.get("is_paused"):
        return {"ok": True, "action": "pause", "method": "already_paused", "verified": True, "state": before}

    attempts: List[Dict[str, Any]] = []

    # 1) Official Moonraker pause endpoint.  This printer's PAUSE macro performs
    # parking/cleanup and can take > 6 seconds, so allow enough time to finish.
    try:
        result = _moonraker_http(req.base_url, "/printer/print/pause", req.api_key, "POST", timeout=35.0)
        state = _moonraker_pause_state(req.base_url, req.api_key)
        attempts.append({"method": "moonraker_native", "ok": True, "state": state})
        if state.get("is_paused"):
            return {"ok": True, "action": "pause", "method": "moonraker_native", "verified": True, "fallback_used": False, "state": state, "attempts": attempts, "moonraker": result.get("body")}
    except HTTPException as exc:
        # A long-running PAUSE macro may outlive the HTTP client timeout even though
        # Klipper did pause.  Always verify state before deciding it failed.
        state = _moonraker_pause_state(req.base_url, req.api_key)
        attempts.append({"method": "moonraker_native", "ok": False, "error": exc.detail, "state": state})
        if state.get("is_paused"):
            return {"ok": True, "action": "pause", "method": "moonraker_native_verified_after_http_error", "verified": True, "fallback_used": False, "state": state, "attempts": attempts}

    # 2) Fall back to known Klipper macros.  Verify after each one because the
    # gcode/script API can return HTTP 200 for an unknown command.
    requested = (req.pause_command or "PAUSE").strip() or "PAUSE"
    commands = []
    for cmd in (requested, "FLUIDD_PAUSE_PRINT", "PAUSE"):
        if cmd and cmd.upper() not in {x.upper() for x in commands}:
            commands.append(cmd)

    for command in commands:
        try:
            result = _moonraker_http(req.base_url, "/printer/gcode/script", req.api_key, "POST", {"script": command}, timeout=35.0)
            state = _moonraker_pause_state(req.base_url, req.api_key)
            attempts.append({"method": "gcode", "command": command, "ok": True, "state": state})
            if state.get("is_paused"):
                return {"ok": True, "action": "pause", "method": "gcode_verified", "command": command, "verified": True, "fallback_used": True, "state": state, "attempts": attempts, "moonraker": result.get("body")}
        except HTTPException as exc:
            state = _moonraker_pause_state(req.base_url, req.api_key)
            attempts.append({"method": "gcode", "command": command, "ok": False, "error": exc.detail, "state": state})
            if state.get("is_paused"):
                return {"ok": True, "action": "pause", "method": "gcode_verified_after_http_error", "command": command, "verified": True, "fallback_used": True, "state": state, "attempts": attempts}

    raise HTTPException(status_code=502, detail="Pause command was sent but AlphaSlice could not verify that the printer entered the paused state. Attempts: " + json.dumps(attempts)[:1800])


@app.post("/api/fluidd/test")
async def fluidd_test(req: FluiddConnectionRequest) -> JSONResponse:
    info = _moonraker_http(req.base_url, "/printer/info", req.api_key, "GET")
    state = None
    filename = None
    try:
        stats = _moonraker_http(req.base_url, "/printer/objects/query?print_stats", req.api_key, "GET")
        ps = ((stats.get("body") or {}).get("result") or {}).get("status", {}).get("print_stats", {})
        state = ps.get("state")
        filename = ps.get("filename")
    except Exception:
        pass
    body = info.get("body") or {}
    result = body.get("result") if isinstance(body, dict) else {}
    return JSONResponse({"ok": True, "base_url": _normalize_moonraker_base_url(req.base_url), "klippy_state": (result or {}).get("state"), "hostname": (result or {}).get("hostname"), "print_state": state, "filename": filename})


@app.post("/api/fluidd/action")
async def fluidd_action(req: FluiddActionRequest) -> JSONResponse:
    action = (req.action or "pause").strip().lower()
    if action == "pause":
        return JSONResponse(_moonraker_pause(req))
    if action == "cancel":
        result = _moonraker_http(req.base_url, "/printer/print/cancel", req.api_key, "POST")
        return JSONResponse({"ok": True, "action": "cancel", "method": "moonraker_cancel", "moonraker": result.get("body")})
    if action == "resume":
        result = _moonraker_http(req.base_url, "/printer/print/resume", req.api_key, "POST")
        return JSONResponse({"ok": True, "action": "resume", "method": "moonraker_resume", "moonraker": result.get("body")})
    raise HTTPException(status_code=400, detail="Unsupported printer action.")


@app.post("/api/visionops/discord")
async def visionops_discord(req: VisionOpsDiscordRequest) -> JSONResponse:
    url = req.webhook_url.strip()
    if not (url.startswith("https://discord.com/api/webhooks/") or url.startswith("https://discordapp.com/api/webhooks/")):
        raise HTTPException(status_code=400, detail="Enter a valid Discord webhook URL.")
    i = req.incident or {}
    sev = str(i.get("severity", "")).lower()
    channel_type = (req.channel_type or "update").strip().lower()
    failure_route = channel_type == "failure"
    color = 0xFF5264 if failure_route or sev in {"high", "critical"} else (0xFFD54A if sev in {"medium", "warning"} else 0x44D7B6)
    route_label = "FAILURE ALERT" if failure_route else "PRINT UPDATE"
    embed = {
        "title": f"{route_label} — " + str(i.get("failure_type") or "Vision OPS event"),
        "description": str(i.get("explanation") or "Vision OPS event")[:4096],
        "color": color,
        "fields": [
            {"name": "Status", "value": str(i.get("status") or "Monitoring"), "inline": True},
            {"name": "Severity", "value": str(i.get("severity") or "unknown"), "inline": True},
            {"name": "Confidence", "value": f"{round(float(i.get('confidence') or 0) * 100)}%", "inline": True},
            {"name": "Probable cause", "value": str(i.get("probable_cause") or "Not determined")[:1024], "inline": False},
            {"name": "Recommended action", "value": str(i.get("recommended_action") or "Continue monitoring")[:1024], "inline": False},
        ],
        "footer": {"text": "AlphaSlice · Vision OPS"},
    }
    if i.get("printer_action"):
        embed["fields"].append({"name": "Printer intervention", "value": str(i.get("printer_action"))[:1024], "inline": False})

    image_bytes = None
    image_mime = "image/jpeg"
    if req.image_data_url and req.image_data_url.startswith("data:image/"):
        try:
            header, b64 = req.image_data_url.split(",", 1)
            image_mime = header.split(";")[0].split(":", 1)[1] or "image/jpeg"
            image_bytes = base64.b64decode(b64, validate=False)
            if image_bytes:
                embed["image"] = {"url": "attachment://vision_snapshot.jpg"}
        except Exception:
            image_bytes = None

    payload = {"username": "Vision OPS", "embeds": [embed]}
    try:
        if image_bytes:
            boundary = "----AlphaSliceVisionOPSBoundary" + os.urandom(8).hex()
            chunks = []
            def add_text_part(name: str, value: str) -> None:
                chunks.append(f"--{boundary}\r\n".encode())
                chunks.append(f'Content-Disposition: form-data; name="{name}"\r\n\r\n'.encode())
                chunks.append(value.encode("utf-8"))
                chunks.append(b"\r\n")
            add_text_part("payload_json", json.dumps(payload))
            chunks.append(f"--{boundary}\r\n".encode())
            chunks.append(b'Content-Disposition: form-data; name="files[0]"; filename="vision_snapshot.jpg"\r\n')
            chunks.append(f"Content-Type: {image_mime}\r\n\r\n".encode())
            chunks.append(image_bytes)
            chunks.append(b"\r\n")
            chunks.append(f"--{boundary}--\r\n".encode())
            body = b"".join(chunks)
            request = urllib.request.Request(
                url, data=body,
                headers={"Content-Type": f"multipart/form-data; boundary={boundary}", "User-Agent": "AlphaSlice-VisionOPS/1.29"},
                method="POST",
            )
        else:
            request = urllib.request.Request(
                url, data=json.dumps(payload).encode("utf-8"),
                headers={"Content-Type": "application/json", "User-Agent": "AlphaSlice-VisionOPS/1.29"},
                method="POST",
            )
        with urllib.request.urlopen(request, timeout=15) as r:
            code = getattr(r, "status", 204)
        return JSONResponse({"ok": True, "status": code, "image_attached": bool(image_bytes), "channel_type": channel_type})
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="ignore")[:700]
        raise HTTPException(status_code=502, detail=f"Discord rejected the alert ({exc.code}): {detail}")
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Could not send Discord alert: {type(exc).__name__}: {exc}")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app",host="127.0.0.1",port=8765,reload=False)

