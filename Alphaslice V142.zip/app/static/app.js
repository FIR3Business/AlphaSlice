import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { STLLoader } from 'three/addons/loaders/STLLoader.js';
import { OBJLoader } from 'three/addons/loaders/OBJLoader.js';
import { PLYLoader } from 'three/addons/loaders/PLYLoader.js';

const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
let selectedFile = null;
let previewData = null;
let analysisData = null;
let currentMesh = null;
let geometry = null;
let scene, camera, renderer, controls;
let currentView = 'solid';
let baseViewerData = null;
let selectionMode = false;
let selectedFaceIndex = null;
let selectionOverlay = null;
let selectionWireframe = null;
const raycaster = new THREE.Raycaster();
const pointer = new THREE.Vector2();

function toast(msg){
  const t=$('#toast'); t.textContent=msg; t.classList.add('show'); setTimeout(()=>t.classList.remove('show'),3200);
}

function initViewer(){
  const canvas=$('#modelCanvas');
  renderer=new THREE.WebGLRenderer({canvas, antialias:true, alpha:true});
  renderer.setPixelRatio(Math.min(window.devicePixelRatio,2));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  scene=new THREE.Scene();
  camera=new THREE.PerspectiveCamera(40,1,0.01,100000);
  camera.position.set(120,90,120);
  controls=new OrbitControls(camera,canvas); controls.enableDamping=true; controls.dampingFactor=.07;
  const lightA=new THREE.DirectionalLight(0xffffff,2.4); lightA.position.set(2,3,4); scene.add(lightA);
  const lightB=new THREE.DirectionalLight(0x52d9c5,1.3); lightB.position.set(-3,-1,2); scene.add(lightB);
  scene.add(new THREE.AmbientLight(0x9ccccc,1.2));
  const grid=new THREE.GridHelper(1000,50,0x1e4f55,0x113039); grid.position.y=0; grid.material.opacity=.32; grid.material.transparent=true; grid.name='bedGrid'; scene.add(grid);
  canvas.addEventListener('pointerdown', onCanvasPointerDown);
  function loop(){requestAnimationFrame(loop); controls.update(); resizeRenderer(); renderer.render(scene,camera)} loop();
}

function resizeRenderer(){
  const canvas=renderer.domElement, parent=canvas.parentElement, w=parent.clientWidth, h=parent.clientHeight;
  if(canvas.width!==Math.floor(w*renderer.getPixelRatio())||canvas.height!==Math.floor(h*renderer.getPixelRatio())){
    renderer.setSize(w,h,false); camera.aspect=w/h; camera.updateProjectionMatrix();
  }
}

function clearSupportMesh(){}


function buildGeometryFromData(data, nonIndexed=false){
  const g=new THREE.BufferGeometry();
  g.setAttribute('position',new THREE.Float32BufferAttribute(data.vertices,3));
  g.setIndex(data.faces); g.computeVertexNormals(); g.computeBoundingBox();
  return nonIndexed ? g.toNonIndexed() : g;
}

function loadViewerMesh(data, preserveCamera=false){
  baseViewerData=data;
  if(selectionOverlay){scene.remove(selectionOverlay); selectionOverlay.geometry.dispose(); selectionOverlay.material.dispose(); selectionOverlay=null;}
  if(selectionWireframe){scene.remove(selectionWireframe); selectionWireframe.geometry.dispose(); selectionWireframe.material.dispose(); selectionWireframe=null;}
  selectionMode=false;
  if(controls) controls.enabled=true;
  const selectBtn=$('#selectBedFaceBtn'); if(selectBtn){selectBtn.classList.remove('ready-select');selectBtn.textContent='Select print-bed face';}
  const selectionStatus=$('#selectionStatus'); if(selectionStatus){selectionStatus.textContent='Not selecting';selectionStatus.classList.remove('ready');}
  selectedFaceIndex=null;
  if(currentMesh){scene.remove(currentMesh); currentMesh.geometry.dispose(); currentMesh.material.dispose();}
  geometry=buildGeometryFromData(data,false);
  const material=new THREE.MeshStandardMaterial({color:0x7edac3,roughness:.5,metalness:.08,side:THREE.DoubleSide,vertexColors:false});
  currentMesh=new THREE.Mesh(geometry,material);
  currentMesh.rotation.x=-Math.PI/2;
  scene.add(currentMesh);
  const box=new THREE.Box3().setFromObject(currentMesh); const center=new THREE.Vector3(); box.getCenter(center);
  currentMesh.position.x -= center.x; currentMesh.position.z -= center.z;
  const postBox=new THREE.Box3().setFromObject(currentMesh); currentMesh.position.y -= postBox.min.y;
  const finalBox=new THREE.Box3().setFromObject(currentMesh), size=new THREE.Vector3(); finalBox.getSize(size); const max=Math.max(size.x,size.y,size.z,1);
  if(!preserveCamera){
    camera.position.set(max*1.45,max*1.0,max*1.45); controls.target.set(0,Math.max(size.y*.3,0),0); camera.near=max/1000; camera.far=max*100; camera.updateProjectionMatrix(); controls.update();
  }
  $('#viewerEmpty').style.display='none'; $('#modelCanvas').style.display='block';
  applyView(currentView);
}

function heatColor(v){
  v=Math.max(0,Math.min(1,Number(v)||0));
  // Blue -> cyan/green -> yellow -> red, with red reserved for truly critical regions.
  const stops=[
    [0.00,new THREE.Color(0x1558d6)],
    [0.30,new THREE.Color(0x20bff2)],
    [0.55,new THREE.Color(0xffdf3f)],
    [0.76,new THREE.Color(0xff8a2a)],
    [1.00,new THREE.Color(0xff3344)]
  ];
  for(let i=0;i<stops.length-1;i++){
    const [a,ca]=stops[i],[b,cb]=stops[i+1];
    if(v<=b){const t=(v-a)/Math.max(b-a,1e-9);return ca.clone().lerp(cb,Math.max(0,Math.min(1,t)));}
  }
  return stops[stops.length-1][1].clone();
}

function setLegend(mode){
  const legend=$('#viewerLegend');
  if(mode==='solid'){legend.classList.add('hidden');return;}
  legend.classList.remove('hidden');
  if(mode==='support'){
    $('#viewerLegendTitle').textContent='Support criticality';
    $('#legendHigh').textContent='Critical — support likely';
    $('#legendMid').textContent='Moderate overhang';
    $('#legendLow').textContent='Low / self-supporting';
    $('#viewerLegendNote').textContent='Based on current bed orientation and local overhang angle.';
  }else{
    $('#viewerLegendTitle').textContent='Predicted stress';
    $('#legendHigh').textContent='High predicted load transfer';
    $('#legendMid').textContent='Moderate';
    $('#legendLow').textContent='Low';
    $('#viewerLegendNote').textContent='Intent-aware estimate from geometry + your description. Not FEA.';
  }
}

function applyView(mode){
  currentView=mode;
  const select=$('#viewerModeSelect'); if(select && select.value!==mode) select.value=mode;
  if(!currentMesh || !baseViewerData) return;
  const source=(mode==='stress' ? analysisData?.analysis : (analysisData?.analysis || previewData?.analysis));
  if(mode==='stress' && (!analysisData || !source?.predicted_stress)){
    toast('Run Analyze & Optimize first. Predicted stress uses the part description and load intent.');
    currentView='solid'; if(select)select.value='solid'; mode='solid';
  }
  if(mode==='support' && !source?.support_criticality){
    toast('Support heatmap is still loading.'); currentView='solid'; if(select)select.value='solid'; mode='solid';
  }

  const old=currentMesh.geometry;
  const next=buildGeometryFromData(baseViewerData,mode!=='solid');
  currentMesh.geometry=next; geometry=next; if(old && old!==next) old.dispose();
  currentMesh.material.transparent=false; currentMesh.material.opacity=1;

  if(mode==='solid'){
    currentMesh.material.vertexColors=false; currentMesh.material.color.setHex(0x7edac3); currentMesh.material.needsUpdate=true; setLegend('solid'); return;
  }

  const values=mode==='support' ? source.support_criticality : source.predicted_stress;
  const faceCount=next.attributes.position.count/3;
  const cols=new Float32Array(next.attributes.position.count*3);
  for(let f=0;f<faceCount;f++){
    const c=heatColor(values?.[f]??0);
    for(let k=0;k<3;k++){const o=(f*3+k)*3;cols[o]=c.r;cols[o+1]=c.g;cols[o+2]=c.b;}
  }
  next.setAttribute('color',new THREE.BufferAttribute(cols,3));
  currentMesh.material.vertexColors=true; currentMesh.material.color.setHex(0xffffff); currentMesh.material.needsUpdate=true;
  setLegend(mode);
}

async function showInstantLocalPreview(file){
  const ext=(file.name.split('.').pop()||'').toLowerCase();
  try{
    let g=null;
    if(ext==='stl'){
      const buf=await file.arrayBuffer();
      g=new STLLoader().parse(buf);
    }else if(ext==='ply'){
      const buf=await file.arrayBuffer();
      g=new PLYLoader().parse(buf);
    }else if(ext==='obj'){
      const text=await file.text();
      const obj=new OBJLoader().parse(text);
      const meshes=[];
      obj.traverse(o=>{if(o.isMesh && o.geometry) meshes.push(o.geometry.clone())});
      if(meshes.length) g=meshes[0];
    }
    if(!g) return false;
    g.computeVertexNormals();
    const non=g.index?g.toNonIndexed():g;
    const pos=non.getAttribute('position');
    const verts=Array.from(pos.array);
    const faces=[];
    for(let i=0;i<pos.count;i++) faces.push(i);
    loadViewerMesh({vertices:verts,faces},false);
    $('#orientationStatus').textContent='Importing geometry…';
    return true;
  }catch(err){
    console.warn('Instant local preview unavailable; backend preview will continue.',err);
    return false;
  }
}

function setFaceSelectionState(on){
  selectionMode=on;
  if(controls) controls.enabled=!on;
  const b=$('#selectBedFaceBtn');
  b.classList.toggle('ready-select',on);
  b.textContent=on?'Ready to select':'Select print-bed face';
  const status=$('#selectionStatus');
  if(status){
    status.textContent=on?'Ready to select':'Not selecting';
    status.classList.toggle('ready',on);
  }
  renderer.domElement.classList.toggle('face-pick-cursor',on);
  setTriangleWireframe(on);
}

function setTriangleWireframe(show){
  if(selectionWireframe){
    scene.remove(selectionWireframe);
    selectionWireframe.geometry.dispose();
    selectionWireframe.material.dispose();
    selectionWireframe=null;
  }
  if(!show || !currentMesh) return;
  const wf=new THREE.WireframeGeometry(currentMesh.geometry);
  const mat=new THREE.LineBasicMaterial({color:0xffd84d,transparent:true,opacity:.42,depthTest:true});
  selectionWireframe=new THREE.LineSegments(wf,mat);
  selectionWireframe.rotation.copy(currentMesh.rotation);
  selectionWireframe.position.copy(currentMesh.position);
  selectionWireframe.scale.copy(currentMesh.scale);
  selectionWireframe.renderOrder=5;
  scene.add(selectionWireframe);
}

async function chooseFile(file){
  if(!file) return;
  selectedFile=file; analysisData=null; previewData=null;
  clearSupportMesh();
  setFaceSelectionState(false);
  $('#modelName').textContent=file.name; $('#analyzeBtn').disabled=true;
  $('#viewerEmpty').style.display='none';
  const stats=$$('#modelStats strong'); stats.forEach(x=>x.textContent='…');

  // Render locally first so an STL/OBJ/PLY appears as soon as it is selected,
  // without waiting for server-side geometry analysis.
  const instant=await showInstantLocalPreview(file);
  if(!instant) $('#previewLoading').classList.remove('hidden');

  const fd=new FormData(); fd.append('file',file);
  try{
    const r=await fetch('/api/preview',{method:'POST',body:fd}); const d=await r.json();
    if(!r.ok) throw new Error(d.detail||'Could not load model');
    previewData=d;
    // Replace local preview with normalized backend geometry. Preserve the camera if
    // the local preview is already visible, avoiding a visual flash/recenter.
    loadViewerMesh(d.viewer_mesh,instant);
    updatePreviewStats(d);
    $('#orientationStatus').textContent=d.orientation_label;
    $('#analyzeBtn').disabled=false;
    toast(`${file.name} is visible and ready — choose a print-bed face or Auto-orient`);
  }catch(e){
    selectedFile=null; previewData=null;
    if(!instant){$('#viewerEmpty').style.display='flex';$('#modelName').textContent='No model loaded';}
    toast(e.message);
  }finally{$('#previewLoading').classList.add('hidden');}
}

function updatePreviewStats(d){
  const g=d.geometry, stats=$$('#modelStats strong');
  stats[0].textContent=g.dimensions_mm.join(' × ')+' mm'; stats[1].textContent=g.faces.toLocaleString(); stats[2].textContent=g.watertight?'Yes':'No'; stats[3].textContent=Math.round((d.support?.support_ratio??0)*100)+'%';
}

function onCanvasPointerDown(e){
  if(!selectionMode || !currentMesh || !previewData) return;
  const rect=renderer.domElement.getBoundingClientRect();
  pointer.x=((e.clientX-rect.left)/rect.width)*2-1;
  pointer.y=-((e.clientY-rect.top)/rect.height)*2+1;
  raycaster.setFromCamera(pointer,camera);
  const hits=raycaster.intersectObject(currentMesh,false);
  if(!hits.length){toast('No triangle selected — click directly on the model.');return;}
  const hit=hits[0];
  selectedFaceIndex=hit.faceIndex;
  showFaceHighlight(hit);
  $('#orientationStatus').textContent=`Face #${selectedFaceIndex+1} selected — placing on bed…`;
  setFaceSelectionState(false);
  toast('Face selected — selection is now off; placing it on the print bed…');
  // One-shot selection: after one triangle click the selector returns to normal
  // and the chosen triangle is immediately oriented onto the bed.
  setTimeout(()=>orientModel('face'),120);
}

function showFaceHighlight(hit){
  if(selectionOverlay){scene.remove(selectionOverlay); selectionOverlay.geometry.dispose(); selectionOverlay.material.dispose();}
  const tri=new THREE.BufferGeometry();
  const p=hit.object.geometry.attributes.position;
  let a,b,c;
  if(hit.object.geometry.index){const ia=hit.object.geometry.index.getX(hit.faceIndex*3),ib=hit.object.geometry.index.getX(hit.faceIndex*3+1),ic=hit.object.geometry.index.getX(hit.faceIndex*3+2);a=new THREE.Vector3().fromBufferAttribute(p,ia);b=new THREE.Vector3().fromBufferAttribute(p,ib);c=new THREE.Vector3().fromBufferAttribute(p,ic);}
  else {a=new THREE.Vector3().fromBufferAttribute(p,hit.faceIndex*3);b=new THREE.Vector3().fromBufferAttribute(p,hit.faceIndex*3+1);c=new THREE.Vector3().fromBufferAttribute(p,hit.faceIndex*3+2);}
  tri.setAttribute('position',new THREE.Float32BufferAttribute([...a.toArray(),...b.toArray(),...c.toArray()],3)); tri.computeVertexNormals();
  selectionOverlay=new THREE.Mesh(tri,new THREE.MeshBasicMaterial({color:0x4d9cff,side:THREE.DoubleSide,transparent:true,opacity:.92,depthTest:false}));
  selectionOverlay.rotation.copy(currentMesh.rotation); selectionOverlay.position.copy(currentMesh.position); selectionOverlay.scale.copy(currentMesh.scale); selectionOverlay.renderOrder=10; scene.add(selectionOverlay);
}

async function orientModel(mode){
  if(!previewData) return;
  clearSupportMesh();
  if(mode==='face' && selectedFaceIndex===null){toast('Click “Select print-bed face”, then click a triangle on the model.');return;}
  $('#previewLoading').classList.remove('hidden');
  try{
    const r=await fetch('/api/orient',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({session_id:previewData.session_id,mode,face_index:selectedFaceIndex})}); const d=await r.json();
    if(!r.ok) throw new Error(d.detail||'Orientation failed'); previewData=d; analysisData=null; loadViewerMesh(d.viewer_mesh,true); updatePreviewStats(d); $('#orientationStatus').textContent=d.orientation_label; toast(mode==='auto'?'Auto-orientation applied':'Print-bed orientation updated');
  }catch(e){toast(e.message);}finally{$('#previewLoading').classList.add('hidden');}
}

async function analyze(){
  if(!previewData) return;
  const fd=new FormData(); fd.append('preview_session_id',previewData.session_id); fd.append('prompt',$('#prompt').value); fd.append('groq_api_key',$('#groqKey').value||'');
  $('#analysisProgress').classList.remove('hidden'); $('#analyzeBtn').disabled=true;
  const stages=[['Reading oriented geometry…',16],['Mapping overhangs…',34],['Searching orientations…',51],['Interpreting design intent…',68],['Generating strategies…',84]];
  let si=0; const timer=setInterval(()=>{if(si<stages.length){$('#progressText').textContent=stages[si][0];$('#progressPct').textContent=stages[si][1]+'%';$('#progressBar').style.width=stages[si][1]+'%';si++;}},320);
  try{
    const r=await fetch('/api/analyze',{method:'POST',body:fd}); const d=await r.json(); if(!r.ok) throw new Error(d.detail||'Analysis failed');
    clearInterval(timer); analysisData=d; $('#progressText').textContent='Optimization ready';$('#progressPct').textContent='100%';$('#progressBar').style.width='100%'; loadViewerMesh(d.viewer_mesh,true); renderResults(d); setTimeout(()=>$('#analysisProgress').classList.add('hidden'),900); toast(`Analysis complete — intent: ${d.intent.source}`);
  }catch(e){clearInterval(timer);toast(e.message);$('#analysisProgress').classList.add('hidden');}finally{$('#analyzeBtn').disabled=false;}
}

function renderResults(d){
  updateOrcaStrengthSummary(d);
  // Analysis is complete. AlphaSlice uses its recommended Balanced profile by default.
  const exportBtn=$('#downloadOptimized3mfBtn');
  if(exportBtn) exportBtn.disabled=false;
  const exportStatus=$('#exportProjectStatus');
  if(exportStatus) exportStatus.textContent='Recommended optimized 3MF ready to export';
  syncPluginState();
  const g=d.geometry,best=d.orientation_candidates[0]; updatePreviewStats({geometry:g,support:{support_ratio:best.support_ratio}});
  $('#analysisContent').innerHTML=`<div class="metric-grid"><div class="metric"><span>Surface area</span><strong>${fmt(g.surface_area_mm2)} mm²</strong></div><div class="metric"><span>Solid PLA mass proxy</span><strong>${g.solid_mass_proxy_g_pla} g</strong></div><div class="metric"><span>Best support risk</span><strong>${Math.round(best.support_ratio*100)}%</strong></div></div><div class="analysis-list">${analysisRow('Overhang exposure',Math.min(100,best.support_ratio*260),`${Math.round(best.support_ratio*100)}% face-area proxy`)}${analysisRow('Build height',Math.min(100,best.height/Math.max(...g.dimensions_mm)*100),`${best.height} mm`)}${analysisRow('Mesh complexity',Math.min(100,g.faces/600),`${g.faces.toLocaleString()} faces`)}${analysisRow('Structural map',74,'Heuristic proxy active')}</div><p class="muted" style="margin-top:15px">v0.3 preserves your chosen bed orientation. Full tetrahedral FEA and fixed/load face painting are the next engineering milestone.</p>`;
  const it=d.intent; $('#intentResult').innerHTML=`<div class="intent-pill">Engine: ${esc(it.source)}</div><p class="muted">${esc(it.summary)}</p><div class="intent-pill">Load: ${it.load_newtons??'not specified'}${it.load_newtons?' N':''}</div><div class="intent-pill">Direction: ${it.load_direction}</div>${it.environment.map(x=>`<div class="intent-pill">${x}</div>`).join('')}<div style="margin-top:13px" class="mini-label">ASSUMPTIONS</div>${(it.assumptions.length?it.assumptions:['No additional assumptions.']).map(x=>`<p class="muted">• ${esc(x)}</p>`).join('')}`;
  const optionCards=$('#optionCards');
  if(optionCards){ optionCards.innerHTML=d.options.map(o=>optionCard(o)).join(''); $$('.export-btn').forEach(b=>b.addEventListener('click',()=>export3MF(b.dataset.option))); }
  const orientationCard=$('#orientationCard'), orientationTable=$('#orientationTable');
  if(orientationCard&&orientationTable){ orientationCard.classList.remove('hidden'); orientationTable.innerHTML=`<table class="orientation-table"><thead><tr><th>Orientation</th><th>Support risk</th><th>Height</th><th>Eco score</th></tr></thead><tbody>${d.orientation_candidates.slice(0,6).map((o,i)=>`<tr class="${i===0?'best':''}"><td>${i===0?'★ ':''}${o.name}</td><td>${Math.round(o.support_ratio*100)}%</td><td>${o.height} mm</td><td>${o.eco_score}</td></tr>`).join('')}</tbody></table>`; }
}

function analysisRow(name,pct,value){return `<div class="analysis-row"><span>${name}</span><div class="bar"><i style="width:${pct}%"></i></div><b>${value}</b></div>`}
function optionCard(o){const rec=o.key==='balanced';return `<div class="card option-card ${rec?'recommended':''}" data-key="${o.key}">${rec?'<div class="recommended-tag">RECOMMENDED</div>':''}<div class="option-top"><div><div class="mini-label">${o.key==='eco'?'MINIMUM FOOTPRINT':o.key==='balanced'?'BEST TRADEOFF':'STRUCTURAL MARGIN'}</div><h2>${o.label}</h2></div><span class="saving">−${o.relative_material_saving_pct}% material*</span></div><div class="option-hero">${o.predicted_material_g} g <small>predicted</small></div><div class="option-metrics"><div><span>Support</span><b>${o.predicted_support_g} g</b></div><div><span>Time</span><b>${mins(o.predicted_time_min)}</b></div><div><span>Energy</span><b>${o.predicted_energy_kwh} kWh</b></div><div><span>Target SF</span><b>${o.safety_factor_target}</b></div></div><div class="strategy"><b>Walls:</b> ${o.wall_strategy}<br><b>Infill:</b> ${o.infill_strategy}<br><span style="color:#6e8d92">*Prototype comparison estimate, before slicer/hardware verification.</span></div><button class="btn primary export-btn" data-option="${o.key}">Download optimized 3MF</button></div>`}

async function export3MF(option){if(!analysisData)return;const r=await fetch('/api/export',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({session_id:analysisData.session_id,option,printer:($('#printerSelect')?.value||'creality_k2_plus')})});if(!r.ok){const d=await r.json();toast(d.detail||'Export failed');return;}const blob=await r.blob(),dispo=r.headers.get('content-disposition')||'',m=dispo.match(/filename="([^"]+)"/),name=m?m[1]:`AlphaSlice_${option}.3mf`,u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download=name;document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(u);toast('Optimized 3MF downloaded');}
function fmt(n){return Number(n).toLocaleString(undefined,{maximumFractionDigits:0})} function mins(n){const h=Math.floor(n/60),m=n%60;return h?`${h}h ${m}m`:`${m}m`} function esc(s){return String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}


const backgroundClasses=['bg-hex','bg-carbon','bg-contour','bg-blueprint','bg-gyroid','bg-minimal','bg-hex-motion','bg-contour-motion'];
const themeClasses=['theme-teal','theme-cyan','theme-amber','theme-violet','theme-carbon'];
function applyBackground(value,save=true){
  const valid=['hex','carbon','contour','blueprint','gyroid','minimal','hex-motion','contour-motion'];
  const next=valid.includes(value)?value:'hex';
  document.body.classList.remove(...backgroundClasses);
  document.body.classList.add(`bg-${next}`);
  const sel=$('#backgroundSelect'); if(sel && sel.value!==next) sel.value=next;
  if(save) localStorage.setItem('ecoslice_background',next);
}
function applyTheme(value,save=true){
  const valid=['teal','cyan','amber','violet','carbon'];
  const next=valid.includes(value)?value:'violet';
  document.body.classList.remove(...themeClasses);
  document.body.classList.add(`theme-${next}`);
  const sel=$('#themeSelect'); if(sel && sel.value!==next) sel.value=next;
  if(save) localStorage.setItem('ecoslice_theme',next);
}
const savedBackground=localStorage.getItem('ecoslice_background')||'hex';
const savedTheme=localStorage.getItem('ecoslice_theme')||'violet';
applyTheme(savedTheme,false);
applyBackground(savedBackground,false);
$('#backgroundSelect')?.addEventListener('change',e=>{applyBackground(e.target.value,true);toast(`Background: ${e.target.selectedOptions?.[0]?.textContent||e.target.value}`);});
$('#themeSelect')?.addEventListener('change',e=>{applyTheme(e.target.value,true);toast(`Color theme: ${e.target.selectedOptions?.[0]?.textContent||e.target.value}`);});

$$('.nav-item').forEach(b=>b.addEventListener('click',()=>{$$('.nav-item').forEach(x=>x.classList.remove('active'));b.classList.add('active');$$('.panel-page').forEach(x=>x.classList.remove('active-page'));$('#'+b.dataset.panel).classList.add('active-page')}));
$('#viewerModeSelect')?.addEventListener('change',e=>applyView(e.target.value)); $$('.quick-prompts button').forEach(b=>b.addEventListener('click',()=>{$('#prompt').value=b.dataset.text}));
$('#fileInput').addEventListener('change',e=>chooseFile(e.target.files[0])); $('#fileInput2').addEventListener('change',e=>chooseFile(e.target.files[0])); $('#analyzeBtn').addEventListener('click',analyze);
$('#selectBedFaceBtn').addEventListener('click',()=>{const next=!selectionMode;setFaceSelectionState(next);toast(next?'Ready to select — click one triangle on the model':'Face selection cancelled');});
const savedGroq=localStorage.getItem('alphaslice_groq_key_1')||localStorage.getItem('ecoslice_groq_key')||''; if(savedGroq) $('#groqKey').value=savedGroq;
$('#saveGroqBtn').addEventListener('click',()=>{const key=$('#groqKey').value.trim(); if(key){localStorage.setItem('alphaslice_groq_key_1',key);localStorage.setItem('ecoslice_groq_key',key);if($('#voGroqKey1'))$('#voGroqKey1').value=key;updateGroqKeyStatus();toast('Groq key 1 saved');}else{localStorage.removeItem('alphaslice_groq_key_1');localStorage.removeItem('ecoslice_groq_key');if($('#voGroqKey1'))$('#voGroqKey1').value='';updateGroqKeyStatus();toast('Groq key 1 cleared');}});
$('#autoOrientBtn').addEventListener('click',()=>orientModel('auto')); $('#resetOrientBtn').addEventListener('click',()=>orientModel('reset'));

$('#sampleBtn').addEventListener('click',async()=>{try{const r=await fetch('/samples/demo_bracket.stl'),b=await r.blob();await chooseFile(new File([b],'demo_bracket.stl',{type:'model/stl'}));$('#prompt').value='Shelf bracket carrying 10 kg downward, fixed at the rear mounting region. Prioritize material savings while keeping a safety factor above 2.';}catch(e){toast('Could not load demo model')}});
['dragenter','dragover'].forEach(ev=>$('#viewer').addEventListener(ev,e=>{e.preventDefault();$('#viewer').style.outline='1px solid rgba(68,224,160,.55)'}));
['dragleave','drop'].forEach(ev=>$('#viewer').addEventListener(ev,e=>{$('#viewer').style.outline='none';if(ev==='drop'){e.preventDefault();chooseFile(e.dataTransfer.files[0])}}));
initViewer();



async function downloadOptimizedProject(){
  if(!analysisData){toast('Analyze the part first');return;}
  const btn=$('#downloadOptimized3mfBtn');
  const status=$('#exportProjectStatus');
  const printer=$('#printerSelect')?.value||'creality_k2_plus';
  btn.disabled=true; btn.textContent='Building 3MF…';
  if(status) status.textContent='Running Windows Fix Model repair + embedding AlphaSlice settings…';
  try{
    const r=await fetch('/api/export',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({session_id:analysisData.session_id,option:selectedOrcaOption,printer})});
    if(!r.ok){let d={};try{d=await r.json()}catch{};throw new Error(d.detail||`Export failed (${r.status})`)}
    const blob=await r.blob(),dispo=r.headers.get('content-disposition')||'',m=dispo.match(/filename="([^"]+)"/),name=m?m[1]:`AlphaSlice_${selectedOrcaOption}.3mf`,u=URL.createObjectURL(blob),a=document.createElement('a');
    a.href=u;a.download=name;document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(u);
    const pname=$('#printerSelect')?.selectedOptions?.[0]?.textContent||'selected printer';
    if(status)status.textContent=`Downloaded ${name} · target: ${pname}`;
    toast('Optimized 3MF downloaded');
  }catch(e){toast(e.message);if(status)status.textContent=e.message}
  finally{btn.disabled=false;btn.textContent='Download optimized 3MF';}
}
$('#downloadOptimized3mfBtn')?.addEventListener('click',downloadOptimizedProject);

let selectedOrcaOption='balanced';
function updateOrcaStrengthSummary(d){
  const el=$('#orcaStrengthSummary'); if(!el||!d)return;
  const sr=d.intent?.strength_recommendation; const opt=(d.options||[]).find(x=>x.key===selectedOrcaOption)||d.options?.[0];
  if(!sr||!opt){el.textContent='Analyze the part first.';return;}
  el.innerHTML=`<b>${esc(sr.level)} strength</b> · ${opt.wall_loops} walls · ${opt.infill_density_pct}% ${esc(opt.infill_pattern)} · ${opt.top_shell_layers}/${opt.bottom_shell_layers} top/bottom layers<br><span>${esc((sr.reasons||[]).join(' • '))}</span>`;
}

async function syncPluginState(){
  if(!analysisData)return;
  try{
    await fetch('/api/plugin/sync',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({analysis_session_id:analysisData.session_id,option:selectedOrcaOption})});
  }catch(e){}
}

function updatePluginUI(d){
  const dot=$('#pluginDot'), label=$('#pluginConnectionLabel'), status=$('#pluginStatus');
  if(!dot||!label||!status)return;
  dot.classList.remove('connected','installed');
  if(d.connected){dot.classList.add('connected');label.textContent='Connected to running Orca plugin';status.textContent=`AlphaSlice Bridge ${d.plugin_version||''} is live`;}
  else if(d.installed){dot.classList.add('installed');label.textContent='Installed — restart/activate in Orca';status.textContent=`Installed at ${d.plugin_path}`;}
  else {label.textContent='Not installed';status.textContent=d.orca_found?'Orca found; plugin can be installed.':'Detect OrcaSlicer first.';}
}

async function checkPlugin(){
  const exe=($('#orcaPath').value||'').trim();
  try{
    const u='/api/plugin/status'+(exe?`?executable=${encodeURIComponent(exe)}`:'');
    const r=await fetch(u), d=await r.json(); updatePluginUI(d);
    if(d.connected) toast('AlphaSlice Orca plugin is connected');
    return d;
  }catch(e){$('#pluginStatus').textContent='Plugin status check failed';}
}

async function installPlugin(){
  const btn=$('#installPluginBtn'); btn.disabled=true; btn.textContent='Installing…';
  try{
    const exe=($('#orcaPath').value||'').trim();
    const u='/api/plugin/install'+(exe?`?executable=${encodeURIComponent(exe)}`:'');
    const r=await fetch(u,{method:'POST'}), d=await r.json(); if(!r.ok)throw new Error(d.detail||'Plugin install failed');
    $('#pluginStatus').textContent='Installed. Restart OrcaSlicer, then activate AlphaSlice Bridge in File > Plugins if needed.';
    $('#pluginDot').classList.add('installed'); $('#pluginConnectionLabel').textContent='Installed — restart OrcaSlicer';
    toast('AlphaSlice Bridge installed. Restart OrcaSlicer once.');
  }catch(e){toast(e.message);$('#pluginStatus').textContent=e.message;}
  finally{btn.disabled=false;btn.textContent='Install / Update Plugin';}
}

async function detectOrca(){
  const st=$('#orcaStatus'); if(st) st.textContent='Checking…';
  try{
    const r=await fetch('/api/orca/status'); const d=await r.json();
    if(d.found){
      $('#orcaPath').value=d.path||'';
      const e=d.environment||{};
      if(e.ready){
        const fils=(e.filaments||[]).slice(0,2).join(', ');
        st.textContent=`Ready ✓ · Printer: ${e.printer||'detected'} · Process: ${e.process||'detected'}${fils?` · Filament: ${fils}`:''}`;
      }else{
        st.textContent='OrcaSlicer detected · AlphaSlice is automatically resolving its active environment…';
      }
      toast('OrcaSlicer detected'); checkPlugin();
    }
    else { st.textContent='OrcaSlicer not detected automatically.'; }
  }catch(e){ if(st) st.textContent='Detection failed'; }
}


async function readJsonSafely(response){
  const text=await response.text();
  if(!text) return {};
  try{return JSON.parse(text);}
  catch(e){
    return {detail:`Server returned ${response.status} ${response.statusText}: ${text.slice(0,500)}`};
  }
}

async function openInOrca(){
  if(!previewData){toast('Import a model first.');return;}
  const btn=$('#openOrcaBtn'); btn.textContent='Opening…'; btn.disabled=true;
  try{
    if(!analysisData){throw new Error('Run Analyze & Optimize first so AlphaSlice can determine wall and infill strength settings.');}
    const r=await fetch('/api/orca/open',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({session_id:previewData.session_id,analysis_session_id:analysisData.session_id,option:selectedOrcaOption,executable:($('#orcaPath').value||'').trim()||null})});
    const d=await readJsonSafely(r); if(!r.ok) throw new Error(d.detail||`Could not open OrcaSlicer (HTTP ${r.status})`);
    const a=d.applied, v=d.verification||{};
    $('#orcaStatus').textContent=a?`Project 3MF opened: ${a.wall_loops} walls · ${a.infill_density_pct}% ${a.infill_pattern}${v.verified?' · embedded ✓':''}`:'Opened in OrcaSlicer';
    toast(a?`AlphaSlice Orca project opened — ${a.wall_loops} walls, ${a.infill_density_pct}% infill${v.verified?' (3MF verified)':''}`:'Opened in OrcaSlicer');
  }catch(e){toast(e.message); $('#orcaStatus').textContent=e.message;}
  finally{btn.textContent='Open AlphaSlice Project in OrcaSlicer';btn.disabled=false;}
}



// ===== Vision OPS integrated monitor v1.19 — direct Groq monitoring with primary/backup models =====
let voStream=null;
let voAutoTimer=null;
let voAnalyzeBusy=false;
let voEvidence=[];
let voTimeline=[];
let voRateLimitUntil=0;
let voLastRateLimitLog=0;
let voLastRateLimitDiscord=0;
let voPrinterActionBusy=false;
let voPrinterActionCooldownUntil=0;
let voGroqKeyIndex=Number(localStorage.getItem('alphaslice_groq_rotation_index')||0);
let voGroqKeyCooldowns={1:0,2:0,3:0};
let voSharedGroqCooldownUntil=0;
let voGroqKeyUseCounts=JSON.parse(localStorage.getItem('alphaslice_groq_use_counts')||'{"1":0,"2":0,"3":0}');
let voDiagnostics=[];
let voSentinelTimer=null;
let voSentinelBaseline=null;
let voSentinelHits=0;
let voLastSentinelTrigger=0;
let voLastAiScanAt=0;
const ALPHASLICE_BUILD='v1.41 EXPERIMENTAL';

function voDiagSanitize(value){
  if(value==null)return value;
  if(typeof value==='string'){
    let s=value;
    s=s.replace(/gsk_[A-Za-z0-9_-]+/g,'[REDACTED_GROQ_KEY]');
    s=s.replace(/https:\/\/discord(?:app)?\.com\/api\/webhooks\/[^\s"']+/gi,'[REDACTED_DISCORD_WEBHOOK]');
    s=s.replace(/([?&](?:key|token|api_key)=)[^&\s]+/gi,'$1[REDACTED]');
    return s;
  }
  if(Array.isArray(value))return value.map(voDiagSanitize);
  if(typeof value==='object'){
    const out={};
    Object.entries(value).forEach(([k,v])=>{
      if(/api.?key|secret|token|webhook/i.test(k))out[k]=v?'[REDACTED]':'';
      else out[k]=voDiagSanitize(v);
    });
    return out;
  }
  return value;
}
function voDiagDiagnosis(code,message=''){
  const map={
    groq_rate_limit:'Groq rate limit reached. AlphaSlice must wait for the provider cooldown before the next AI scan.',
    groq_daily_limit:'Groq daily token budget is exhausted. Local Sentinel will continue watching without API usage until Groq resets.',
    groq_request_failed:'Groq vision request failed. Check the HTTP/error detail in the exported log.',
    groq_key_missing:'No Groq API key is available to Vision OPS.',
    discord_send_failed:'Discord delivery failed. The webhook may be invalid, unreachable, rate-limited, or Discord rejected the payload.',
    fluidd_connection_failed:'AlphaSlice could not reach Moonraker behind Fluidd. Check the address, Moonraker service, network, and API-key requirement.',
    fluidd_action_failed:'AlphaSlice reached printer-control logic but the requested pause/cancel action failed.',
    camera_error:'The browser could not start or keep the camera stream.',
    js_error:'A browser JavaScript error occurred.',
    promise_error:'An asynchronous browser operation failed without being handled.',
    diagnostic:'AlphaSlice recorded a diagnostic event.'
  };
  return map[code]||message||'AlphaSlice recorded an issue. See the details below.';
}
function voDiagRender(){
  const count=$('#voDiagCount'),latest=$('#voDiagLatest'),list=$('#voDiagnosticsList');
  if(count)count.textContent=String(voDiagnostics.length);
  if(latest)latest.textContent=voDiagnostics.length?voDiagnostics[0].diagnosis:'No issues recorded';
  if(!list)return;
  list.innerHTML=voDiagnostics.length?voDiagnostics.slice(0,30).map(x=>`<div class="vo-diag-item ${esc(x.level||'warning')}"><div class="vo-diag-line"><b>${esc(x.subsystem||'AlphaSlice')} · ${esc(x.code||'issue')}</b><span>${esc(new Date(x.timestamp).toLocaleTimeString())}</span></div><div class="vo-diag-diagnosis">${esc(x.diagnosis||'')}</div><code>${esc(x.message||'')}</code></div>`).join(''):'<div class="vo-empty-log">No diagnostic issues yet.</div>';
}
function voDiagIssue(code,message,details={},level='warning',subsystem='Vision OPS'){
  const entry={
    timestamp:new Date().toISOString(),
    build:ALPHASLICE_BUILD,
    level,subsystem,code,
    diagnosis:voDiagDiagnosis(code,message),
    message:voDiagSanitize(String(message||'')),
    details:voDiagSanitize(details||{})
  };
  voDiagnostics.unshift(entry);voDiagnostics=voDiagnostics.slice(0,300);
  try{localStorage.setItem('alphaslice_diagnostics_v1',JSON.stringify(voDiagnostics));}catch(_e){}
  voDiagRender();
  return entry;
}
function voDiagConfigSnapshot(){
  const fluidd=voFluiddConfig();
  return {
    build:ALPHASLICE_BUILD,
    exported_at:new Date().toISOString(),
    browser:navigator.userAgent,
    page_origin:location.origin,
    camera_active:!!voStream,
    auto_monitor:!!$('#voAutoMonitor')?.checked,
    detection_frequency_ms:voFrequencyMs(),
    groq_key_slots_configured:getGroqKeys().length,
    rate_limit_remaining_ms:Math.max(0,voRateLimitUntil-Date.now()),
    shared_groq_cooldown_ms:Math.max(0,voSharedGroqCooldownUntil-Date.now()),
    local_sentinel_active:!!voSentinelTimer,
    local_sentinel_hits:voSentinelHits,
    discord_updates_configured:!!($('#voUpdateWebhook')?.value||'').trim(),
    discord_failures_configured:!!($('#voFailureWebhook')?.value||'').trim(),
    fluidd_configured:!!fluidd.base_url,
    fluidd_address:fluidd.base_url||'',
    fluidd_pause_command:fluidd.pause_command||'',
    auto_pause_enabled:!!$('#voAutoPausePrinter')?.checked,
    current_state:{
      status:$('#voMachineStatus')?.textContent||'',
      confidence:$('#voConfidence')?.textContent||'',
      risk:$('#voSeverity')?.textContent||'',
      detection:$('#voFailureType')?.textContent||'',
      explanation:$('#voExplanation')?.textContent||'',
      recommended_action:$('#voRecommendedAction')?.textContent||''
    }
  };
}
function voExportDiagnostics(){
  const snapshot=voDiagConfigSnapshot();
  const lines=[];
  lines.push('AlphaSlice Diagnostic Log');
  lines.push('========================');
  lines.push(`Build: ${snapshot.build}`);
  lines.push(`Exported: ${snapshot.exported_at}`);
  lines.push(`Browser: ${snapshot.browser}`);
  lines.push(`Camera active: ${snapshot.camera_active}`);
  lines.push(`Auto monitor: ${snapshot.auto_monitor}`);
  lines.push(`Detection frequency: ${snapshot.detection_frequency_ms} ms`);
  lines.push(`Groq key slots configured: ${snapshot.groq_key_slots_configured}`);
  lines.push(`Rate-limit cooldown remaining: ${snapshot.rate_limit_remaining_ms} ms`);
  lines.push(`Shared Groq cooldown remaining: ${snapshot.shared_groq_cooldown_ms} ms`);
  lines.push(`Local sentinel active: ${snapshot.local_sentinel_active}`);
  lines.push(`Local sentinel hits: ${snapshot.local_sentinel_hits}`);
  lines.push(`Discord update route configured: ${snapshot.discord_updates_configured}`);
  lines.push(`Discord failure route configured: ${snapshot.discord_failures_configured}`);
  lines.push(`Fluidd configured: ${snapshot.fluidd_configured}`);
  lines.push(`Fluidd address: ${snapshot.fluidd_address}`);
  lines.push(`Pause command: ${snapshot.fluidd_pause_command}`);
  lines.push(`Auto-pause enabled: ${snapshot.auto_pause_enabled}`);
  lines.push('');
  lines.push('Current Vision OPS state');
  lines.push('------------------------');
  Object.entries(snapshot.current_state).forEach(([k,v])=>lines.push(`${k}: ${v}`));
  lines.push('');
  lines.push(`Diagnostic issues (${voDiagnostics.length})`);
  lines.push('------------------------');
  voDiagnostics.forEach((x,i)=>{
    lines.push(`#${i+1} ${x.timestamp} [${x.level}] ${x.subsystem} / ${x.code}`);
    lines.push(`Diagnosis: ${x.diagnosis}`);
    lines.push(`Message: ${x.message}`);
    lines.push(`Details: ${JSON.stringify(x.details)}`);
    lines.push('');
  });
  lines.push('Monitoring timeline');
  lines.push('-------------------');
  voTimeline.forEach((x,i)=>lines.push(`#${i+1} ${x.time} [${x.kind}] ${x.title}${x.detail?' — '+x.detail:''}`));
  lines.push('');
  lines.push('Machine-readable snapshot');
  lines.push('-------------------------');
  lines.push(JSON.stringify({snapshot,diagnostics:voDiagnostics,timeline:voTimeline},null,2));
  const blob=new Blob([lines.join('\n')],{type:'text/plain;charset=utf-8'});
  const url=URL.createObjectURL(blob),a=document.createElement('a');
  a.href=url;a.download=`AlphaSlice_Diagnostic_${new Date().toISOString().replace(/[:.]/g,'-')}.txt`;document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url);
  toast('Diagnostic log exported — send the .txt file with your screenshot.');
}
function voLoadDiagnostics(){
  try{const saved=JSON.parse(localStorage.getItem('alphaslice_diagnostics_v1')||'[]');if(Array.isArray(saved))voDiagnostics=saved.slice(0,300);}catch(_e){voDiagnostics=[];}
  voDiagRender();
}
window.addEventListener('error',e=>voDiagIssue('js_error',e.message||'JavaScript error',{filename:e.filename||'',line:e.lineno||0,column:e.colno||0},'danger','Browser'));
window.addEventListener('unhandledrejection',e=>voDiagIssue('promise_error',String(e.reason?.message||e.reason||'Unhandled promise rejection'),{},'danger','Browser'));

function voSetStatus(label,kind='monitoring'){
  const pill=$('#voStatusPill'); if(!pill)return;
  pill.className=`vo-status ${kind}`; const txt=pill.querySelector('b'); if(txt)txt.textContent=label;
  const ms=$('#voMachineStatus'); if(ms)ms.textContent=label;
}
function voLog(title,detail='',kind='monitoring'){
  voTimeline.unshift({title,detail,kind,time:new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit',second:'2-digit'})});
  voTimeline=voTimeline.slice(0,40);
  const el=$('#voTimeline'); if(!el)return;
  el.innerHTML=voTimeline.map(x=>`<div class="vo-log-item ${esc(x.kind)}"><span class="vo-log-dot"></span><div class="vo-log-copy"><b>${esc(x.title)}</b><span>${esc(x.time)}${x.detail?' · '+esc(x.detail):''}</span></div></div>`).join('')||'<div class="vo-empty-log">No Vision OPS events yet.</div>';
}
async function voStartCamera(){
  try{
    if(voStream) voStream.getTracks().forEach(t=>t.stop());
    voStream=await navigator.mediaDevices.getUserMedia({video:{width:{ideal:1280},height:{ideal:720}},audio:false});
    const v=$('#voVideo'); v.srcObject=voStream; v.style.display='block'; $('#voVideoEmpty').style.display='none'; const scan=$('.vo-scanline'); if(scan)scan.style.display='none';
    $('#voStartCamera').textContent='Restart camera'; $('#voStopCamera').disabled=false; $('#voAnalyzeFrame').disabled=false; $('#voAutoMonitor').disabled=false;
    voEvidence=[]; voRateLimitUntil=0;
    voSetStatus('Monitoring','healthy'); voLog('Camera connected',`Local monitor ${Math.round(voSentinelFrequencyMs()/1000)}s · Groq heartbeat ${voFrequencyMs()<60000?Math.round(voFrequencyMs()/1000)+'s':Math.round(voFrequencyMs()/60000)+'min'} · shared-quota aware`,'monitoring');
  }catch(e){toast('Camera unavailable: '+e.message);voLog('Camera error',e.message,'warning');voDiagIssue('camera_error',e.message,{name:e.name||''},'danger','Camera');}
}
function voStopCamera(){
  if(voStream){voStream.getTracks().forEach(t=>t.stop());voStream=null;}
  const v=$('#voVideo'); if(v){v.srcObject=null;v.style.display='none';} if($('#voVideoEmpty'))$('#voVideoEmpty').style.display='flex'; const sc=$('.vo-scanline');if(sc)sc.style.display='none';
  if(voAutoTimer){clearInterval(voAutoTimer);voAutoTimer=null;} voStopSentinel(); if($('#voAutoMonitor'))$('#voAutoMonitor').checked=false;
  $('#voStopCamera').disabled=true;$('#voAnalyzeFrame').disabled=true;$('#voAutoMonitor').disabled=true;voSetStatus('Idle','monitoring');voLog('Camera stopped','','monitoring');
}
function voSentinelMetrics(){
  const v=$('#voVideo'); if(!v||!voStream||v.videoWidth<2)return null;
  const w=160,h=90,c=document.createElement('canvas');c.width=w;c.height=h;
  const ctx=c.getContext('2d',{willReadFrequently:true});
  // Prioritize the lower 62% where spaghetti, loose strands, and detached material accumulate.
  const sy=Math.floor(v.videoHeight*.38),sh=Math.max(1,v.videoHeight-sy);
  ctx.drawImage(v,0,sy,v.videoWidth,sh,0,0,w,h);
  const d=ctx.getImageData(0,0,w,h).data;
  let edges=0,lum=0,bright=0;
  const gray=new Float32Array(w*h);
  for(let i=0,p=0;i<d.length;i+=4,p++){const g=.299*d[i]+.587*d[i+1]+.114*d[i+2];gray[p]=g;lum+=g;if(g>205)bright++;}
  for(let y=1;y<h-1;y+=2){for(let x=1;x<w-1;x+=2){const i=y*w+x;const gx=Math.abs(gray[i+1]-gray[i-1]),gy=Math.abs(gray[i+w]-gray[i-w]);if(gx+gy>52)edges++;}}
  return {edgeDensity:edges/(((w-2)*(h-2))/4),mean:lum/(w*h),bright:bright/(w*h),gray,w,h};
}
function voSentinelTick(){
  if(!voStream||!$('#voAutoMonitor')?.checked)return;
  const m=voSentinelMetrics();if(!m)return;
  if(!voSentinelBaseline){voSentinelBaseline={edgeDensity:m.edgeDensity,mean:m.mean,bright:m.bright,gray:m.gray};return;}
  let diff=0;const prev=voSentinelBaseline.gray;for(let i=0;i<m.gray.length;i+=3)diff+=Math.abs(m.gray[i]-prev[i]);diff/=Math.ceil(m.gray.length/3)*255;
  const edgeRatio=m.edgeDensity/Math.max(.003,voSentinelBaseline.edgeDensity);
  const brightJump=m.bright-voSentinelBaseline.bright;
  // Spaghetti tends to add many thin edges/strands and persistent scene change in the lower bed region.
  const suspicious=(edgeRatio>1.28&&diff>.045)||(edgeRatio>1.16&&diff>.075)||(brightJump>.08&&diff>.06);
  voSentinelHits=suspicious?Math.min(5,voSentinelHits+1):Math.max(0,voSentinelHits-1);
  // Slow baseline adaptation prevents ordinary gantry/nozzle motion from permanently triggering the detector.
  const a=suspicious?.03:.10;
  voSentinelBaseline={edgeDensity:voSentinelBaseline.edgeDensity*(1-a)+m.edgeDensity*a,mean:voSentinelBaseline.mean*(1-a)+m.mean*a,bright:voSentinelBaseline.bright*(1-a)+m.bright*a,gray:m.gray};
  if(voSentinelHits>=3&&Date.now()-voLastSentinelTrigger>90000&&!voAnalyzeBusy){
    voLastSentinelTrigger=Date.now();voSentinelHits=0;
    voLog('Local Sentinel trigger',`sustained lower-bed visual change · edge x${edgeRatio.toFixed(2)} · diff ${Math.round(diff*100)}%`,'warning');
    voDiagIssue('diagnostic','Local Sentinel detected sustained visual change',{edge_ratio:Number(edgeRatio.toFixed(3)),frame_diff:Number(diff.toFixed(3)),bright_jump:Number(brightJump.toFixed(3))},'warning','Local Sentinel');
    if(Date.now()>=voSharedGroqCooldownUntil&&Date.now()>=voRateLimitUntil){
      voAnalyzeFrame(false,'sentinel');
    }else{
      const image=voCaptureFrame(640,.55);
      voSetStatus('Local warning','warning');
      $('#voFailureType').textContent='Local Sentinel detected a sustained visual change';
      $('#voExplanation').textContent='Groq is unavailable because the shared organization quota is cooling down. AlphaSlice is continuing local monitoring and captured this event for review.';
      $('#voRecommendedAction').textContent='Inspect the print or wait for Groq confirmation when quota returns.';
      if($('#voDiscordAuto')?.checked&&image){voSendDiscord('update',{status:'Monitoring',failure_type:'Local Sentinel visual-change warning',severity:'medium',confidence:0.55,probable_cause:'Persistent visual change detected locally while Groq quota is unavailable',explanation:'AlphaSlice local monitoring detected a sustained change in the lower build-plate region. AI confirmation is temporarily unavailable because Groq is in a shared quota cooldown.',recommended_action:'Inspect the live print. AlphaSlice will resume AI confirmation automatically when Groq quota recovers.'},image,false);}
    }
  }
}
function voSentinelFrequencyMs(){return Math.max(30000,Number($('#voSentinelFrequency')?.value||localStorage.getItem('alphaslice_sentinel_frequency_ms')||30000));}
function voStartSentinel(){if(voSentinelTimer)clearInterval(voSentinelTimer);voSentinelBaseline=null;voSentinelHits=0;voSentinelTimer=setInterval(voSentinelTick,voSentinelFrequencyMs());}
function voStopSentinel(){if(voSentinelTimer){clearInterval(voSentinelTimer);voSentinelTimer=null;}voSentinelBaseline=null;voSentinelHits=0;}

function voCaptureFrame(maxW=640,quality=.55){
  const v=$('#voVideo'),c=$('#voCapture'); if(!v||!voStream||v.videoWidth<2)return null;
  // Vision composite: left = full frame, right = enlarged lower build-plate region.
  // This keeps one Groq image request while making spaghetti near the front/edges much harder to miss.
  const outW=Math.max(480,Math.min(maxW,720)),outH=Math.round(outW*0.56);
  c.width=outW;c.height=outH;const ctx=c.getContext('2d');
  ctx.fillStyle='#000';ctx.fillRect(0,0,outW,outH);
  const gap=4,leftW=Math.floor((outW-gap)*0.56),rightW=outW-gap-leftW;
  const fullScale=Math.min(leftW/v.videoWidth,outH/v.videoHeight);
  const fw=Math.round(v.videoWidth*fullScale),fh=Math.round(v.videoHeight*fullScale);
  ctx.drawImage(v,0,0,v.videoWidth,v.videoHeight,Math.floor((leftW-fw)/2),Math.floor((outH-fh)/2),fw,fh);
  // Crop from lower ~62% of the camera image, where bed failures/spaghetti commonly appear.
  const sy=Math.floor(v.videoHeight*0.38),sh=v.videoHeight-sy;
  const cropScale=Math.max(rightW/v.videoWidth,outH/sh);
  const cw=Math.round(v.videoWidth*cropScale),ch=Math.round(sh*cropScale);
  ctx.save();ctx.beginPath();ctx.rect(leftW+gap,0,rightW,outH);ctx.clip();
  ctx.drawImage(v,0,sy,v.videoWidth,sh,leftW+gap+Math.floor((rightW-cw)/2),Math.floor((outH-ch)/2),cw,ch);
  ctx.restore();
  return c.toDataURL('image/jpeg',quality);
}
function voSetScanning(active){const scan=$('.vo-scanline');if(scan)scan.style.display=active?'block':'none';}

function getGroqKeys(){
  const slots=[1,2,3].map(i=>({slot:i,key:((document.querySelector(`#voGroqKey${i}`)?.value)||localStorage.getItem(`alphaslice_groq_key_${i}`)||'').trim()})).filter(x=>x.key);
  if(!slots.length){const legacy=(document.querySelector('#groqKey')?.value||localStorage.getItem('ecoslice_groq_key')||'').trim();if(legacy)slots.push({slot:1,key:legacy});}
  return slots;
}
function nextGroqKey(){
  const keys=getGroqKeys();
  if(!keys.length)return null;
  const now=Date.now();
  if(now<voSharedGroqCooldownUntil)return null;
  // Strict round-robin across configured slots. Temporarily limited slots are skipped until their own cooldown expires.
  for(let offset=0;offset<keys.length;offset++){
    const idx=(voGroqKeyIndex+offset)%keys.length;
    const candidate=keys[idx];
    if(now>=(voGroqKeyCooldowns[candidate.slot]||0)){
      voGroqKeyIndex=(idx+1)%keys.length;
      localStorage.setItem('alphaslice_groq_rotation_index',String(voGroqKeyIndex));
      voGroqKeyUseCounts[candidate.slot]=(Number(voGroqKeyUseCounts[candidate.slot])||0)+1;
      localStorage.setItem('alphaslice_groq_use_counts',JSON.stringify(voGroqKeyUseCounts));
      updateGroqKeyStatus();
      return candidate;
    }
  }
  return null;
}
function earliestGroqCooldown(){
  const keys=getGroqKeys(); if(!keys.length)return 0;
  const vals=keys.map(x=>Number(voGroqKeyCooldowns[x.slot]||0)).filter(v=>v>Date.now());
  return vals.length?Math.min(...vals):0;
}
function updateGroqKeyStatus(){
  const keys=getGroqKeys(),el=$('#voGroqKeyStatus');
  if(!el)return;
  if(!keys.length){el.textContent='No Groq keys saved.';return;}
  const parts=keys.map(x=>`Key ${x.slot}: ${Number(voGroqKeyUseCounts[x.slot]||0)} scans${Date.now()<(voGroqKeyCooldowns[x.slot]||0)?' · cooling':''}`);
  if(Date.now()<voSharedGroqCooldownUntil)el.textContent=`Shared Groq quota cooling · all keys paused together · resumes in ${Math.ceil((voSharedGroqCooldownUntil-Date.now())/1000)}s · ${parts.join(' · ')}`;
  else el.textContent=`Balanced key rotation for AI confirmations · ${parts.join(' · ')}`;
}

function voFluiddConfig(){
  return {
    base_url: ($('#voFluiddUrl')?.value||localStorage.getItem('alphaslice_fluidd_url')||'').trim(),
    api_key: ($('#voFluiddApiKey')?.value||localStorage.getItem('alphaslice_fluidd_api_key')||'').trim(),
    pause_command: ($('#voFluiddPauseCommand')?.value||localStorage.getItem('alphaslice_fluidd_pause_command')||'PAUSE').trim()||'PAUSE'
  };
}
function voSaveFluiddConfig(){
  const c=voFluiddConfig();
  if(c.base_url)localStorage.setItem('alphaslice_fluidd_url',c.base_url);else localStorage.removeItem('alphaslice_fluidd_url');
  if(c.api_key)localStorage.setItem('alphaslice_fluidd_api_key',c.api_key);else localStorage.removeItem('alphaslice_fluidd_api_key');
  localStorage.setItem('alphaslice_fluidd_pause_command',c.pause_command);
  localStorage.setItem('alphaslice_fluidd_auto_pause',$('#voAutoPausePrinter')?.checked?'1':'0');
  const st=$('#voFluiddStatus');if(st)st.textContent=c.base_url?'Printer connection saved. Test it before relying on automatic intervention.':'Printer control not configured.';
}
async function voTestFluidd(){
  const c=voFluiddConfig();if(!c.base_url){toast('Enter the Fluidd / Moonraker address first.');return false;}
  const st=$('#voFluiddStatus');if(st)st.textContent='Testing Moonraker connection…';
  try{
    const r=await fetch('/api/fluidd/test',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(c)});
    const d=await readJsonSafely(r);if(!r.ok)throw new Error(d.detail||'Connection test failed');
    const parts=[d.hostname||'Moonraker',d.klippy_state?`Klippy: ${d.klippy_state}`:'',d.print_state?`Print: ${d.print_state}`:'',d.filename||''].filter(Boolean);
    if(st)st.textContent='Connected · '+parts.join(' · ');toast('Fluidd / Moonraker connected');voLog('Printer control connected',parts.join(' · '),'healthy');return true;
  }catch(e){if(st)st.textContent='Connection failed: '+e.message;toast(e.message);voLog('Printer control connection failed',e.message,'warning');voDiagIssue('fluidd_connection_failed',e.message,{address:c.base_url},'danger','Fluidd / Moonraker');return false;}
}
async function voFluiddAction(action='pause',auto=false){
  if(voPrinterActionBusy)return {ok:false,detail:'Printer action already in progress'};
  const c=voFluiddConfig();if(!c.base_url){if(!auto)toast('Configure Fluidd / Moonraker first.');return {ok:false,detail:'Printer control not configured'};}
  if(auto&&Date.now()<voPrinterActionCooldownUntil)return {ok:false,detail:'Automatic printer action cooldown active'};
  voPrinterActionBusy=true;const st=$('#voFluiddStatus');if(st)st.textContent=`Sending ${action} to printer…`;
  try{
    const r=await fetch('/api/fluidd/action',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...c,action})});
    const d=await readJsonSafely(r);if(!r.ok)throw new Error(d.detail||`Printer ${action} failed`);
    if(action==='pause')voPrinterActionCooldownUntil=Date.now()+60000;
    const detail=action==='pause'
      ?(d.verified?`Print pause VERIFIED (${d.method}${d.command?' · '+d.command:''})`:`Pause request sent (${d.method||'Moonraker'})`)
      :`Print ${action} command sent`;
    if(st)st.textContent=detail+'.';voLog(action==='pause'?'Printer paused':'Printer '+action,detail,action==='cancel'?'danger':'warning');if(!auto)toast(detail);return {...d,detail};
  }catch(e){if(st)st.textContent=`Printer control error: ${e.message}`;voLog('Printer intervention failed',e.message,'danger');voDiagIssue('fluidd_action_failed',e.message,{action,address:c.base_url,pause_command:c.pause_command,automatic:auto},'danger','Fluidd / Moonraker');if(!auto)toast(e.message);return {ok:false,detail:e.message};}
  finally{voPrinterActionBusy=false;}
}

function voResultKind(d){const sev=(d.severity||'').toLowerCase(),st=(d.status||'').toLowerCase();if(sev==='critical'||sev==='high'||st.includes('attention'))return 'danger';if(sev==='medium'||sev==='warning'||sev==='low')return 'warning';if(st.includes('printing')||st.includes('healthy')||st.includes('monitoring'))return 'healthy';return 'monitoring';}
async function voAnalyzeFrame(manual=false,trigger=manual?'manual':'heartbeat'){
  if(voAnalyzeBusy)return;
  const now=Date.now();
  if(!manual && now<voRateLimitUntil)return;
  const image=voCaptureFrame(640,.55); if(!image){if(manual)toast('Start the camera first.');return;}
  voAnalyzeBusy=true; voLastAiScanAt=Date.now(); $('#voAnalyzeFrame').disabled=true; voSetScanning(true); voSetStatus(manual?'AI analyzing':trigger==='sentinel'?'AI confirming':'Auto scan','analyzing');
  try{
    const activeCredential=nextGroqKey();
    if(!activeCredential){
      const nextReady=earliestGroqCooldown();
      if(nextReady){voRateLimitUntil=nextReady;throw new Error(`All configured Groq keys are cooling down for about ${Math.ceil((nextReady-Date.now())/1000)}s.`);}
      voDiagIssue('groq_key_missing','No Groq API key saved.',{},'danger','Groq Vision');throw new Error('No Groq API key saved.');
    }
    const activeKey=activeCredential.key;
    const activeSlot=activeCredential.slot;
    voLog('Groq scan',`Using API key slot ${activeSlot}`,'monitoring');
    const r=await fetch('/api/visionops/analyze',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({image_data_url:image,api_key:activeKey,context:($('#voContext')?.value||'')})});
    const d=await readJsonSafely(r); if(!r.ok){voDiagIssue('groq_request_failed',d.detail||'Vision analysis failed',{http_status:r.status,response:d},'danger','Groq Vision');throw new Error(d.detail||'Vision analysis failed');}
    if(d.rate_limited){
      const retry=Math.max(5,Number(d.retry_after_seconds)||20);
      const daily=/tokens per day|TPD/i.test(d.explanation||'');
      if(daily){
        voSharedGroqCooldownUntil=Date.now()+retry*1000;
        getGroqKeys().forEach(x=>{voGroqKeyCooldowns[x.slot]=voSharedGroqCooldownUntil;});
        voRateLimitUntil=voSharedGroqCooldownUntil;
      }else{
        voGroqKeyCooldowns[activeSlot]=Date.now()+retry*1000;
      }
      const allCooling=daily||getGroqKeys().every(x=>Date.now()<(voGroqKeyCooldowns[x.slot]||0));
      if(!daily)voRateLimitUntil=allCooling?earliestGroqCooldown():0;
      voDiagIssue(daily?'groq_daily_limit':'groq_rate_limit',`Groq key slot ${activeSlot} requested a ${Math.ceil(retry)}s cooldown`,{key_slot:activeSlot,retry_after_seconds:retry,source:d.source||'',model:d.model||null,provider_explanation:d.explanation||''},'warning','Groq Vision');
      voSetStatus('Groq cooldown','warning'); $('#voConfidence').textContent='—'; $('#voSeverity').textContent='info'; $('#voFailureType').textContent='Groq cooldown';
      $('#voExplanation').textContent=daily?`Groq reported a shared organization/model daily-token limit. All configured keys use the same quota, so AlphaSlice paused all Groq requests for about ${Math.ceil(retry)}s instead of wasting requests on the next key. Local monitoring continues.`:(allCooling?`All configured Groq keys are temporarily cooling down. The next available slot should recover in about ${Math.ceil(Math.max(0,earliestGroqCooldown()-Date.now())/1000)}s.`:`Groq key slot ${activeSlot} is cooling down for about ${Math.ceil(retry)}s. AlphaSlice will use the next available key for short/key-specific throttles.`);
      $('#voRecommendedAction').textContent='Camera remains live. Vision OPS will resume automatically after the API cooldown.';
      if(Date.now()-voLastRateLimitLog>15000){voLastRateLimitLog=Date.now();voLog('Groq rate limit',`Key ${activeSlot} cooling for ${Math.ceil(retry)}s${allCooling?' · all keys cooling':''}`,'warning');}
      // Discord is independent of Groq. Send one monitoring-system warning (with this snapshot)
      // so the user is not left with a silent channel while AI is throttled.
      if($('#voDiscordAuto')?.checked && Date.now()-voLastRateLimitDiscord>120000){
        voLastRateLimitDiscord=Date.now();
        await voSendDiscord('update',{status:'Monitoring',failure_type:'AI scan temporarily rate-limited',severity:'info',confidence:0,probable_cause:'Groq token/request quota cooldown',explanation:`AlphaSlice paused AI requests for about ${Math.ceil(retry)} seconds to recover quota. The camera remains live.`,recommended_action:'No printer action taken. AI monitoring will resume automatically.'},image,false);
      }
      return;
    }
    voRateLimitUntil=0;
    const kind=voResultKind(d);
    const suspicious=kind==='danger'||kind==='warning';
    const anomalyType=String(d.failure_type||'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();
    voEvidence.push({suspicious,type:anomalyType,confidence:Number(d.confidence)||0});
    voEvidence=voEvidence.slice(-3);
    const sameTypeCount=suspicious?voEvidence.filter(x=>x.suspicious&&x.type===anomalyType).length:0;
    const critical=(String(d.severity||'').toLowerCase()==='critical');
    const confirmed=critical||(suspicious&&sameTypeCount>=2);

    if(suspicious&&!confirmed){
      voSetStatus('Checking','analyzing');
      $('#voConfidence').textContent=d.confidence!=null?`${Math.round(Number(d.confidence)*100)}%`:'—';
      $('#voSeverity').textContent='possible';
      $('#voFailureType').textContent=`Possible ${d.failure_type||'anomaly'} — confirming`;
      $('#voExplanation').textContent=`Single-frame indication only. AlphaSlice will require the same anomaly in another recent scan before escalating. ${d.explanation||''}` + (d.model?` Model: ${d.model}.`:'');
      $('#voRecommendedAction').textContent='Continue monitoring — waiting for repeat visual evidence before taking action.';
      if($('#voAutoMonitor')?.checked&&voStream){setTimeout(()=>{if(Date.now()>=voRateLimitUntil)voAnalyzeFrame(false);},5000);}
    }else{
      voSetStatus(d.status||'Monitoring',kind);
      $('#voConfidence').textContent=d.confidence!=null?`${Math.round(Number(d.confidence)*100)}%`:'—';
      $('#voSeverity').textContent=d.severity||'—';
      $('#voFailureType').textContent=d.failure_type||'No visible failure';
      $('#voExplanation').textContent=(d.explanation||'No explanation returned.') + (d.model?` Model: ${d.model}.`:'');
      $('#voRecommendedAction').textContent=d.recommended_action||'Continue monitoring';
    }
    voLog(d.failure_type||d.status,`${d.severity||'unknown'} · ${d.confidence!=null?Math.round(d.confidence*100)+'%':'confidence n/a'}${d.model?' · '+d.model:''}${confirmed?' · confirmed':suspicious?' · awaiting confirmation':''}`,confirmed?'danger':suspicious?'warning':kind);
    if(confirmed&&$('#voAutoPausePrinter')?.checked){
      const printerResult=await voFluiddAction('pause',true);
      d.printer_action=printerResult.ok?printerResult.detail:`Automatic pause failed: ${printerResult.detail}`;
      if(printerResult.ok){$('#voRecommendedAction').textContent='AlphaSlice paused the printer automatically. Inspect the print before resuming.';}
    }
    if($('#voDiscordAuto')?.checked){
      if(confirmed){
        await voSendDiscord('failure',d,image,false);
      }else{
        await voSendDiscord('update',d,image,false);
      }
    }
  }catch(e){
    if(manual)toast(e.message);
    voSetStatus('Monitoring','healthy');
    $('#voFailureType').textContent='Groq vision unavailable';
    $('#voExplanation').textContent=e.message||'Vision OPS could not reach Groq.';
    $('#voRecommendedAction').textContent='Check the Groq key or try again.';
    if(Date.now()-voLastRateLimitLog>60000){voLastRateLimitLog=Date.now();voLog('Groq unavailable',e.message||'Request failed','warning');}
    voDiagIssue('groq_request_failed',e.message||'Request failed',{network_or_client_error:true},'danger','Groq Vision');
  }finally{
    voAnalyzeBusy=false; voSetScanning(false); if(voStream)$('#voAnalyzeFrame').disabled=false;
  }
}
async function voSendDiscord(route='update',result=null,image=null,test=false){
  const selector=route==='failure'?'#voFailureWebhook':'#voUpdateWebhook';
  const webhook=($(selector)?.value||'').trim();
  if(!webhook){if(test)toast(`Add the ${route==='failure'?'failure':'update'} Discord webhook first.`);return false;}
  let snapshot=image;
  if(!snapshot&&voStream)snapshot=voCaptureFrame(640,.72);
  const payload=result||(route==='failure'
    ?{status:'Needs Attention',failure_type:'Vision OPS failure webhook test',severity:'high',confidence:1,probable_cause:'Webhook test only',explanation:'AlphaSlice Vision OPS failure-route webhook test.',recommended_action:'No action required — this is a test.'}
    :{status:'Monitoring',failure_type:'Vision OPS update webhook test',severity:'info',confidence:1,probable_cause:'Normal operation',explanation:'AlphaSlice Vision OPS normal-update webhook test.',recommended_action:'Continue monitoring.'});
  if(test&&!snapshot){toast('Start the camera first so the test webhook can include a snapshot.');return false;}
  try{
    const r=await fetch('/api/visionops/discord',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({webhook_url:webhook,incident:payload,image_data_url:snapshot||null,test,channel_type:route})});
    const d=await readJsonSafely(r);if(!r.ok){voDiagIssue('discord_send_failed',d.detail||'Discord alert failed',{http_status:r.status,route,response:d,image_attached:!!snapshot},'danger','Discord');throw new Error(d.detail||'Discord alert failed');}
    $('#voWebhookStatus').textContent=`Discord ${route==='failure'?'failure alert':'normal update'} sent successfully${d.image_attached?' with snapshot':''}.`;
    if(test)toast(`${route==='failure'?'Failure':'Update'} test alert sent with image`);
    return true;
  }catch(e){$('#voWebhookStatus').textContent='Discord error: '+e.message;voDiagIssue('discord_send_failed',e.message,{route,test,image_attached:!!snapshot},'danger','Discord');if(test)toast(e.message);return false;}
}

function getGroqKey(){const keys=getGroqKeys();return keys[0]||'';}
function syncGroqKeyInputs(){const keys=[1,2,3].map(i=>localStorage.getItem(`alphaslice_groq_key_${i}`)||'');keys.forEach((v,idx)=>{const el=document.querySelector(`#voGroqKey${idx+1}`);if(el)el.value=v;});if($('#groqKey'))$('#groqKey').value=keys[0]||localStorage.getItem('ecoslice_groq_key')||'';updateGroqKeyStatus();}
function saveGroqKeys(){
  let count=0;
  [1,2,3].forEach(i=>{const el=document.querySelector(`#voGroqKey${i}`);const key=(el?.value||'').trim();if(key){localStorage.setItem(`alphaslice_groq_key_${i}`,key);count++;}else localStorage.removeItem(`alphaslice_groq_key_${i}`);});
  const first=localStorage.getItem('alphaslice_groq_key_1')||'';if(first){localStorage.setItem('ecoslice_groq_key',first);if($('#groqKey'))$('#groqKey').value=first;}else localStorage.removeItem('ecoslice_groq_key');
  voGroqKeyIndex=0;voGroqKeyCooldowns={1:0,2:0,3:0};voSharedGroqCooldownUntil=0;voGroqKeyUseCounts={1:0,2:0,3:0};localStorage.setItem('alphaslice_groq_rotation_index','0');localStorage.setItem('alphaslice_groq_use_counts',JSON.stringify(voGroqKeyUseCounts));updateGroqKeyStatus();toast(count?`${count} Groq key${count===1?'':'s'} saved · balanced rotation reset`:'No Groq keys saved');
}
function clearGroqKeys(){[1,2,3].forEach(i=>localStorage.removeItem(`alphaslice_groq_key_${i}`));localStorage.removeItem('ecoslice_groq_key');[1,2,3].forEach(i=>{const el=document.querySelector(`#voGroqKey${i}`);if(el)el.value='';});if($('#groqKey'))$('#groqKey').value='';voGroqKeyIndex=0;voGroqKeyCooldowns={1:0,2:0,3:0};voSharedGroqCooldownUntil=0;voGroqKeyUseCounts={1:0,2:0,3:0};localStorage.removeItem('alphaslice_groq_rotation_index');localStorage.removeItem('alphaslice_groq_use_counts');updateGroqKeyStatus();toast('Groq keys cleared');}
function voFrequencyMs(){return Math.max(15000,Number($('#voDetectionFrequency')?.value||localStorage.getItem('ecoslice_visionops_frequency_ms')||1800000));}
function voRestartAutoTimer(){if(voAutoTimer){clearInterval(voAutoTimer);voAutoTimer=null;}if($('#voAutoMonitor')?.checked&&voStream){const ms=voFrequencyMs();voAutoTimer=setInterval(()=>voAnalyzeFrame(false,'heartbeat'),ms);}}
function initVisionOps(){
  voLoadDiagnostics();
  const updateWh=localStorage.getItem('alphaslice_visionops_update_webhook')||localStorage.getItem('ecoslice_visionops_webhook')||'';
  const failureWh=localStorage.getItem('alphaslice_visionops_failure_webhook')||'';
  if($('#voUpdateWebhook'))$('#voUpdateWebhook').value=updateWh;if($('#voFailureWebhook'))$('#voFailureWebhook').value=failureWh;
  if((updateWh||failureWh)&&$('#voWebhookStatus'))$('#voWebhookStatus').textContent='Discord webhook routes saved in this browser.';
  syncGroqKeyInputs();
  let savedFreq=Number(localStorage.getItem('ecoslice_visionops_frequency_ms')||0);if(savedFreq<15000)savedFreq=1800000;localStorage.setItem('ecoslice_visionops_frequency_ms',String(savedFreq));if($('#voDetectionFrequency'))$('#voDetectionFrequency').value=String(savedFreq);
  const savedSentinel=Math.max(30000,Number(localStorage.getItem('alphaslice_sentinel_frequency_ms')||30000));localStorage.setItem('alphaslice_sentinel_frequency_ms',String(savedSentinel));if($('#voSentinelFrequency'))$('#voSentinelFrequency').value=String(savedSentinel);
  $('#voStartCamera')?.addEventListener('click',voStartCamera);$('#voStopCamera')?.addEventListener('click',voStopCamera);$('#voAnalyzeFrame')?.addEventListener('click',()=>voAnalyzeFrame(true));
  $('#voSaveGroqKeys')?.addEventListener('click',saveGroqKeys);$('#voClearGroqKeys')?.addEventListener('click',clearGroqKeys);
  $('#voDetectionFrequency')?.addEventListener('change',e=>{const value=String(Math.max(15000,Number(e.target.value)||1800000)); localStorage.setItem('ecoslice_visionops_frequency_ms',value); voRestartAutoTimer(); const ms=Number(value); const label=ms<60000?`${Math.round(ms/1000)}s`:ms<3600000?`${Math.round(ms/60000)}min`:`${Math.round(ms/3600000)}hr`; voLog('AI heartbeat updated',`Groq heartbeat every ${label}`,'monitoring');});
  $('#voSentinelFrequency')?.addEventListener('change',e=>{const value=String(Math.max(30000,Number(e.target.value)||30000));localStorage.setItem('alphaslice_sentinel_frequency_ms',value);if($('#voAutoMonitor')?.checked&&voStream)voStartSentinel();voLog('Local monitoring frequency updated',`Local visual check every ${Math.round(Number(value)/1000)}s`,'monitoring');});
  $('#voAutoMonitor')?.addEventListener('change',e=>{if(voAutoTimer){clearInterval(voAutoTimer);voAutoTimer=null;}if(e.target.checked){voEvidence=[];voStartSentinel();voRestartAutoTimer();voLog('Automatic monitoring enabled',`Local monitor every ${Math.round(voSentinelFrequencyMs()/1000)}s · Groq heartbeat every ${voFrequencyMs()<60000?Math.round(voFrequencyMs()/1000)+'s':Math.round(voFrequencyMs()/60000)+'min'} · anomaly-triggered AI confirmation`,'monitoring');}else{voStopSentinel();voLog('Automatic monitoring disabled','','monitoring');}});
  $('#voSaveUpdateWebhook')?.addEventListener('click',()=>{const v=($('#voUpdateWebhook')?.value||'').trim();if(v){localStorage.setItem('alphaslice_visionops_update_webhook',v);$('#voWebhookStatus').textContent='Normal updates webhook saved.';toast('Normal updates webhook saved');}else{localStorage.removeItem('alphaslice_visionops_update_webhook');$('#voWebhookStatus').textContent='Normal updates webhook cleared.';toast('Normal updates webhook cleared');}});
  $('#voSaveFailureWebhook')?.addEventListener('click',()=>{const v=($('#voFailureWebhook')?.value||'').trim();if(v){localStorage.setItem('alphaslice_visionops_failure_webhook',v);$('#voWebhookStatus').textContent='Failure alerts webhook saved.';toast('Failure alerts webhook saved');}else{localStorage.removeItem('alphaslice_visionops_failure_webhook');$('#voWebhookStatus').textContent='Failure alerts webhook cleared.';toast('Failure alerts webhook cleared');}});
  $('#voTestUpdateDiscord')?.addEventListener('click',()=>voSendDiscord('update',null,null,true));
  $('#voTestFailureDiscord')?.addEventListener('click',()=>voSendDiscord('failure',null,null,true));
  const fluiddUrl=localStorage.getItem('alphaslice_fluidd_url')||'';if($('#voFluiddUrl'))$('#voFluiddUrl').value=fluiddUrl;
  const fluiddKey=localStorage.getItem('alphaslice_fluidd_api_key')||'';if($('#voFluiddApiKey'))$('#voFluiddApiKey').value=fluiddKey;
  const fluiddCommand=localStorage.getItem('alphaslice_fluidd_pause_command')||'PAUSE';if($('#voFluiddPauseCommand'))$('#voFluiddPauseCommand').value=fluiddCommand;
  if($('#voAutoPausePrinter'))$('#voAutoPausePrinter').checked=localStorage.getItem('alphaslice_fluidd_auto_pause')==='1';
  if(fluiddUrl&&$('#voFluiddStatus'))$('#voFluiddStatus').textContent='Printer connection saved. Test it before relying on automatic intervention.';
  $('#voSaveFluidd')?.addEventListener('click',()=>{voSaveFluiddConfig();toast('Fluidd / Moonraker settings saved');});
  $('#voTestFluidd')?.addEventListener('click',voTestFluidd);
  $('#voPausePrinter')?.addEventListener('click',()=>voFluiddAction('pause',false));
  $('#voCancelPrinter')?.addEventListener('click',()=>{if(confirm('Cancel the current print? This cannot be resumed.'))voFluiddAction('cancel',false);});
  $('#voAutoPausePrinter')?.addEventListener('change',()=>voSaveFluiddConfig());
  $('#voClearTimeline')?.addEventListener('click',()=>{voTimeline=[];$('#voTimeline').innerHTML='<div class="vo-empty-log">No Vision OPS events yet.</div>';});
  $('#voExportDiagnostics')?.addEventListener('click',voExportDiagnostics);
  $('#voClearDiagnostics')?.addEventListener('click',()=>{voDiagnostics=[];localStorage.removeItem('alphaslice_diagnostics_v1');voDiagRender();toast('Diagnostic log cleared');});
}
initVisionOps();
