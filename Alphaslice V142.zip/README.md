# AlphaSlice v1.43 EXPERIMENTAL — Verified Moonraker Pause

- Fixes printer pause reliability based on the supplied K2 Plus Klippy log.
- Uses Moonraker `/printer/print/pause` as the primary pause method.
- Allows up to 35 seconds because the K2 Plus PAUSE macro performs parking/cleanup before the request completes.
- Verifies `pause_resume.is_paused` / `print_stats.state` after every pause attempt.
- Falls back to the configured command, `FLUIDD_PAUSE_PRINT`, and `PAUSE` only when needed.
- Never treats a successful HTTP response alone as proof that a G-code command worked.
- Default fallback command changed from invalid `PAUSE_PRINT` to `PAUSE`.
- v1.33 remains the stable checkpoint.
