@echo off
setlocal
cd /d "%~dp0"
title AlphaSlice Launcher

echo.
echo =====================================================
echo   AlphaSlice v1.24 - AI Manufacturing Copilot
echo =====================================================
echo.

where py >nul 2>&1
if %errorlevel%==0 (
  set PYTHON=py
) else (
  where python >nul 2>&1
  if %errorlevel% neq 0 (
    echo [ERROR] Python 3 is not installed or not in PATH.
    echo Install Python 3.11+ from python.org, then run this file again.
    pause
    exit /b 1
  )
  set PYTHON=python
)

if not exist ".venv\Scripts\python.exe" (
  echo [1/4] Creating local Python environment...
  %PYTHON% -m venv .venv
  if errorlevel 1 goto :fail
) else (
  echo [1/4] Local environment found.
)

call ".venv\Scripts\activate.bat"

echo [2/4] Checking dependencies...
python -c "import fastapi,uvicorn,trimesh,numpy,multipart,lxml,networkx,skimage" >nul 2>&1
if errorlevel 1 (
  echo       Installing required packages. This happens only when needed...
  python -m pip install --upgrade pip
  python -m pip install -r requirements.txt
  if errorlevel 1 goto :fail
) else (
  echo       Dependencies already installed.
)

echo [3/4] Starting AlphaSlice at http://127.0.0.1:8765
start "AlphaSlice Browser" cmd /c "timeout /t 2 /nobreak >nul & start http://127.0.0.1:8765"

echo [4/4] AlphaSlice is running. Keep this window open.
echo       Press Ctrl+C to stop.
echo.
python -m uvicorn app.main:app --host 127.0.0.1 --port 8765
exit /b 0

:fail
echo.
echo [ERROR] AlphaSlice could not start. Copy the error above into ChatGPT and I can diagnose it.
pause
exit /b 1
