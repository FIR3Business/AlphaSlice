#!/bin/bash
cd "$(dirname "$0")"
if [ ! -d ".venv" ]; then python3 -m venv .venv; fi
source .venv/bin/activate
python -c "import fastapi,uvicorn,trimesh,numpy,multipart,lxml,networkx" >/dev/null 2>&1 || pip install -r requirements.txt
(sleep 2; open http://127.0.0.1:8765) &
python -m uvicorn app.main:app --host 127.0.0.1 --port 8765
